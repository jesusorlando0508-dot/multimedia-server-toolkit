document.addEventListener('DOMContentLoaded', function () {

    // ===============================
    // 1. Crear contenedor para temporadas debajo de los tags
    // ===============================
    const tagsDiv = document.querySelector('.tags');
    if (tagsDiv) {
        const contenedorTemporadas = document.createElement('div');
        contenedorTemporadas.id = 'contenedor-temporadas';
        tagsDiv.insertAdjacentElement('afterend', contenedorTemporadas);
    }

    // ===============================
    // 2. Configurar lista de episodios para guardar en localStorage y redirigir a V1.HTML
    // ===============================
    const videoLists = document.querySelectorAll('.episode-list');

    videoLists.forEach(list => {
        const videoItems = list.getElementsByTagName('li');
        const videos = [];
        const titles = [];

        for (let i = 0; i < videoItems.length; i++) {
            const videoSrc = videoItems[i].getAttribute('data-src');
            const videoTitle = videoItems[i].textContent.trim();

            // make items keyboard-focusable and announceable
            videoItems[i].tabIndex = 0;
            videoItems[i].setAttribute('role', 'button');
            videoItems[i].setAttribute('aria-label', videoTitle);

            videos.push(videoSrc);
            titles.push(videoTitle);

            const selectEpisode = function () {
                // Guardar información del episodio seleccionado en localStorage
                localStorage.setItem('currentVideo', videoSrc);
                localStorage.setItem('videoTitle', videoTitle);
                localStorage.setItem('mainTitle', document.querySelector('header h1').textContent);
                localStorage.setItem('videoIndex', i);
                localStorage.setItem('videoList', JSON.stringify(videos));
                localStorage.setItem('videoTitles', JSON.stringify(titles));

                // Redirigir al reproductor
                window.location.href = "/media_all/V1.HTML";
            };

            videoItems[i].addEventListener('click', selectEpisode);

            // keyboard activation (Enter / Space)
            videoItems[i].addEventListener('keydown', function (ev) {
                if (ev.key === 'Enter' || ev.key === ' ') {
                    ev.preventDefault();
                    selectEpisode.call(this);
                }
            });
        }
    });

    // ===============================
    // 3. Actualizar href de los enlaces de género para redirigir con query ?tag=
    // ===============================
    document.querySelectorAll('a.tag').forEach(enlace => {
        const genero = enlace.textContent.trim();
        enlace.href = "/Carusel.html?tag=" + encodeURIComponent(genero);
    });

    // ===============================
    // 4. Cargar temporadas de la misma serie desde anime.json
    // ===============================

    // Obtener el título base eliminando posibles números de temporada al final
    const tituloBase = document.querySelector('header h1').textContent.replace(/ \(\d+\)$/, '').trim();

    fetch('/anime.json')
        .then(response => response.json())
        .then(data => {
            // Filtrar series que empiecen con el mismo título base
            const seriesTemporadas = data.filter(serie => serie.title.startsWith(tituloBase));

            if (seriesTemporadas.length > 0) {
                const listaTemporadas = document.createElement('ul');

                // Opcional: excluir la primera entrada (siempre que se desee omitir la temporada actual)
                const seriesFiltradas = seriesTemporadas.filter((_, index) => index >= 1);

                seriesFiltradas.forEach((serie, index) => {
                    const temporadaItem = document.createElement('li');
                    const enlace = document.createElement('a');

                    // Ajuste de ruta para Linux
                    const rutaLink = serie.link.replace(/\\/g, '/');
                    enlace.href = rutaLink;

                    enlace.textContent = serie.title;

                    enlace.addEventListener('click', function () {
                        const siguienteTemporada = seriesFiltradas[index + 1];
                        if (siguienteTemporada) {
                            document.querySelector('header h1').textContent = siguienteTemporada.title;
                        }
                    });

                    temporadaItem.appendChild(enlace);
                    listaTemporadas.appendChild(temporadaItem);
                });


                // Insertar la lista en el contenedor de temporadas
                const contenedorTemporadas = document.querySelector('#contenedor-temporadas');
                if (contenedorTemporadas) {
                    contenedorTemporadas.innerHTML = '';
                    contenedorTemporadas.appendChild(listaTemporadas);
                }
            } else {
                console.error('No se encontraron temporadas para esta serie.');
            }
        })
        .catch(error => console.error('Error al cargar el archivo JSON:', error));
});
