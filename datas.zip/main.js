// =========================
// VARIABLES GLOBALES
// =========================
let movies = [];
let currentIndex = 1;
const itemsPerPage = 5;
// Pagination and performance tuning
const PAGE_SIZE = 25;
let currentPage = 1;
let totalPages = 1;
let filteredList = [];
const MAX_CAROUSEL_ITEMS = 20;
let carouselInitialized = false;
let isAnimating = false;
let searchTimeout = null;
let carouselInterval = null;

let heroQueue = [];
let heroIndex = 0;
let heroIntervalId = null;
let heroActionsBound = false;
const HERO_ROTATION_MS = 9000;

const MY_LIST_STORAGE_KEY = 'animezone.myList';
let myListMap = new Map();

let allCatalogItems = [];
let activeGenres = new Set();
let currentView = 'catalog';
let standaloneMovies = [];
let detailDataPromise = null;
const detailCache = new Map();
const modalState = {
    root: null,
    overlay: null,
    body: null,
    title: null,
    description: null,
    meta: null,
    tags: null,
    playBtn: null,
    listBtn: null,
    link: null,
    media: null,
    poster: null,
    video: null,
    eyebrow: null,
    episodes: null,
    closeBtn: null,
    previousFocus: null,
    currentItem: null
};
let currentTypeFilter = 'anime';
let currentSearchTerm = '';
let navEventsBound = false;
let modalEventsBound = false;
const DETAIL_DATA_PATH = 'anime1_info.json';
const PLAYER_PATH = '/media_all/V1.HTML';
const hoverPreviewState = {
    initialized: false,
    preview: null,
    video: null,
    title: null,
    text: null,
    addBtn: null,
    playBtn: null,
    volumeBtn: null,
    isMuted: true,
    mainList: [],
    detailList: [],
    currentTrailers: [],
    currentIndex: 0,
    activeElement: null,
    activeAnime: null,
    activeEpisodes: [],
    previewVisible: false,
    dimensions: { width: 0, height: 0 }
};

// =========================
// UTILIDADES DE DATOS COMPARTIDAS
// =========================
async function loadAndFixJSON(url) {
    try {
        const response = await fetch(url);
        let data = await response.json();
        if (!Array.isArray(data)) return data;
        return data.map(item => {
            if (item.image) {
                item.image = item.image.replace(/\\/g, '/');
                const parts = item.image.split('/');
                const fileName = parts.pop();
                const encoded = encodeURIComponent(fileName);
                item.image = [...parts, encoded].join('/');
            }
            if (item.link) {
                item.link = item.link.replace(/\\/g, '/');
            }
            return item;
        });
    } catch (error) {
        console.error('Error cargando JSON:', error);
        return [];
    }
}

try { window.loadAndFixJSON = loadAndFixJSON; } catch (e) { /* noop */ }

const moviesModule = {
    data: [],
    async init(opts = {}) {
        const containerId = opts.containerId || 'movie-container';
        const container = document.getElementById(containerId);
        const loadingMsg = document.getElementById('loading-message');
        const activeFilter = document.getElementById('active-filter');
        if (loadingMsg) loadingMsg.style.display = 'block';

        let data = [];
        try {
            const dataPath = opts.dataPath || 'anime.json';
            if (opts.loadData === false && Array.isArray(this.data) && this.data.length) {
                data = this.data;
            } else {
                data = await loadAndFixJSON(dataPath);
                if (!Array.isArray(data) || !data.length) {
                    const resp = await fetch(dataPath);
                    data = await resp.json();
                }
            }
        } catch (err) {
            console.error('moviesModule: error loading data', err);
            if (container) container.innerHTML = '<p class="error-message">Error al cargar animes.</p>';
            if (loadingMsg) loadingMsg.style.display = 'none';
            return;
        }

        this.data = Array.isArray(data) ? data : (data || []);
        if (opts.exposeGlobal) {
            try { window.movies = this.data; } catch (e) { /* ignore */ }
        }

        const params = new URLSearchParams(window.location.search);
        const tag = params.get('tag');
        let itemsToRender = this.data;
        if (tag) {
            itemsToRender = this.data.filter(anime => Array.isArray(anime.genres) && anime.genres.includes(tag));
            if (activeFilter) {
                activeFilter.textContent = `Mostrando género: ${tag}`;
                activeFilter.style.display = 'block';
            }
        } else if (opts.typeFilter) {
            const typeFilter = opts.typeFilter.toString().toLowerCase();
            const filteredByType = this.data.filter(i => (i.type || '').toString().toLowerCase() === typeFilter);
            if (filteredByType.length) itemsToRender = filteredByType;
        }

        renderMovieCollection(itemsToRender, container);
        if (loadingMsg) loadingMsg.style.display = 'none';
    },
    filtrarIdioma(idioma, opts = {}) {
        const container = document.getElementById(opts.containerId || 'movie-container');
        const activeFilter = document.getElementById('active-filter');
        const source = (this.data && this.data.length) ? this.data : allCatalogItems;
        if (!source.length || !container) return;
        const filtered = source.filter(m => (m.idioma || '').toString().toLowerCase() === (idioma || '').toString().toLowerCase());
        renderMovieCollection(filtered, container);
        if (activeFilter) {
            activeFilter.textContent = `Filtrando idioma: ${idioma}`;
            activeFilter.style.display = 'block';
        }
    },
    renderAll(containerId) {
        const container = document.getElementById(containerId || 'movie-container');
        if (!container) return;
        renderMovieCollection(this.data, container);
    }
};

function normalizeLinkPath(h) {
    if (!h) return '#';
    try {
        const url = new URL(h, location.href);
        if (['http:', 'https:', 'data:', 'file:'].includes(url.protocol)) return url.href;
    } catch (e) { /* ignore */ }
    return '#';
}

function renderMovieCollection(items = [], container) {
    if (!container) return;
    container.innerHTML = '';
    const frag = document.createDocumentFragment();
    items.forEach(item => {
        const card = createStandardMovieCard({
            ...item,
            link: normalizeLinkPath(item.link || item.url || '#')
        });
        frag.appendChild(card);
    });
    container.appendChild(frag);
}

function renderStandaloneMovieGrid(items = [], container = document.getElementById('movie-grid')) {
    if (!container) return;
    container.classList.add('movies-grid');
    container.innerHTML = '';

    if (!items.length) {
        container.innerHTML = '<p class="empty-message">No se encontraron películas.</p>';
        return;
    }

    const frag = document.createDocumentFragment();
    items.forEach(item => {
        const card = createStandardMovieCard({
            ...item,
            link: normalizeLinkPath(item.link || item.url || '#')
        });
        frag.appendChild(card);
    });
    container.appendChild(frag);
}

try {
    window.moviesModule = moviesModule;
    window.initMovies = (opts) => moviesModule.init(opts);
    window.renderAllMovies = (id) => moviesModule.renderAll(id);
} catch (e) {
    console.warn('No se pudieron exponer los helpers del módulo de películas', e);
}

function filtrarIdioma(idioma) {
    moviesModule.filtrarIdioma(idioma, { containerId: 'movie-container' });
}

try { window.filtrarIdioma = filtrarIdioma; } catch (e) { /* noop */ }

// =========================
// CARGAR PELÍCULAS DESDE JSON
// =========================
async function loadMovies() {
    const loadingMessage = document.getElementById('loading-message');
    try {
        if (loadingMessage) loadingMessage.style.display = 'block';

        initMyList();

        const animeData = await loadAndFixJSON('anime.json');
        const movieData = await loadAdditionalLibrary('movies.json');
        movies = animeData;
        standaloneMovies = Array.isArray(movieData) ? movieData : [];

        console.log('Datos cargados y rutas corregidas:', movies);

        setupHeroSection(animeData, movieData);
        setupFiltersAndView(animeData, movieData);
        const movieGrid = document.getElementById('movie-grid');
        if (movieGrid) {
            renderStandaloneMovieGrid(standaloneMovies, movieGrid);
            movieGrid.style.display = 'none';
        }

        // Inicializar carrusel y búsqueda
        displayMainContent();
    } catch (error) {
        console.error('Error cargando datos:', error);
        if (loadingMessage) {
            loadingMessage.innerText = 'Error al cargar los datos';
            loadingMessage.style.color = 'red';
        }
    } finally {
        if (loadingMessage) loadingMessage.style.display = 'none';
    }
}

function initDetailModal() {
    if (modalEventsBound) return;
    const root = document.getElementById('detail-modal');
    if (!root) return;

    modalState.root = root;
    modalState.overlay = root.querySelector('.detail-modal__overlay');
    modalState.body = root.querySelector('.detail-modal__body');
    modalState.title = document.getElementById('detail-modal-title');
    modalState.description = document.getElementById('detail-modal-description');
    modalState.meta = document.getElementById('detail-modal-meta');
    modalState.tags = document.getElementById('detail-modal-tags');
    modalState.playBtn = document.getElementById('detail-modal-play');
    modalState.listBtn = document.getElementById('detail-modal-list');
    modalState.link = document.getElementById('detail-modal-link');
    modalState.media = document.getElementById('detail-modal-media');
    modalState.poster = document.getElementById('detail-modal-poster');
    modalState.video = document.getElementById('detail-modal-video');
    modalState.eyebrow = document.getElementById('detail-modal-eyebrow');
    modalState.episodes = document.getElementById('detail-modal-episodes');
    modalState.closeBtn = root.querySelector('.detail-modal__close');

    root.querySelectorAll('[data-modal-close]').forEach(el => el.addEventListener('click', closeDetailModal));
    document.addEventListener('keydown', (ev) => {
        if (ev.key === 'Escape' && root.classList.contains('show')) {
            closeDetailModal();
        }
    });

    modalState.playBtn?.addEventListener('click', () => {
        if (modalState.currentItem) handlePlayAction(modalState.currentItem);
    });

    modalState.listBtn?.addEventListener('click', () => {
        if (modalState.currentItem) toggleMyList(modalState.currentItem);
    });

    modalEventsBound = true;
}

async function ensureDetailData() {
    if (!detailDataPromise) {
        detailDataPromise = fetch(DETAIL_DATA_PATH)
            .then(res => res.json())
            .catch(err => {
                console.error('No se pudo cargar el detalle extendido', err);
                return [];
            });
    }
    return detailDataPromise;
}

async function openDetailModal(item = {}) {
    if (!modalState.root) initDetailModal();
    if (!modalState.root) return;

    modalState.currentItem = item;
    modalState.previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    renderBaseModalContent(item);
    // fetch user progress to adapt modal UI (marcado visto/continuar)
    let userProgress = {};
    try {
        const resp = await fetch('/api/get-progress');
        if (resp.ok) userProgress = await resp.json();
    } catch (e) { userProgress = {}; }

    const detailData = await ensureDetailData();
    const linkKey = normalizeLinkKey(item.link || item.title || '');
    const cached = detailCache.get(linkKey);
    const extra = cached || detailData.find(entry => normalizeLinkKey(entry.link) === linkKey);
    if (extra) {
        detailCache.set(linkKey, extra);
        renderExtendedModalContent(extra, userProgress);
    } else {
        renderExtendedModalContent(undefined, userProgress);
    }

    modalState.root.classList.add('show');
    modalState.root.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    requestAnimationFrame(() => {
        modalState.closeBtn?.focus();
    });
}

function renderBaseModalContent(item = {}) {
    modalState.title.textContent = item.title || 'Sin título';
    modalState.description.textContent = item.short_synopsis || item.synopsis || 'Sin sinopsis disponible.';
    modalState.meta.textContent = formatHeroMeta(item);
    const tags = Array.isArray(item.genres) ? item.genres.map(tag => `<span>${tag}</span>`).join('') : '';
    modalState.tags.innerHTML = tags;
    modalState.link.href = item.link || '#';
    modalState.eyebrow.textContent = item.type ? item.type.toUpperCase() : 'DESTACADO';
    setModalPoster(item.image, item.title);
    resetModalMedia();
    setupModalPreview([], item);
    updateModalListButton();
}

function renderExtendedModalContent(extra, progress = {}) {
    const container = modalState.episodes;
    if (!container) return;
    const episodes = sanitizeEpisodeList(extra?.episodes);
    if (!episodes.length) {
        container.innerHTML = '<p>No hay episodios disponibles.</p>';
        return;
    }
    const list = document.createElement('ul');
    list.className = 'modal-episode-list';
    episodes.forEach((ep, idx) => {
        const li = document.createElement('li');
        li.innerHTML = `
            <button type="button" data-episode-index="${idx}" aria-label="Reproducir episodio ${ep.episodeNumber || idx + 1}">
                <span class="episode-number">${ep.episodeNumber || idx + 1}</span>
                <span class="episode-title">${ep.title || 'Episodio'}</span>
                <span class="progress-badge" style="margin-left:8px;font-size:.85em;color:#999"></span>
            </button>
        `;
        const btn = li.querySelector('button');
        // adapt button label/action based on stored progress (keyed by videoPath when available)
        // Use the episode's `videoPath` when available (matches pages/data.js -> localStorage.currentVideo).
        // Fallback to a constructed key when videoPath is missing.
        const vidKey = ep.videoPath || localStorage.getItem('currentVideo') || `${modalState.currentItem?.link || ''}#${ep.episode || idx}`;
        const p = progress && progress[vidKey] ? progress[vidKey] : null;
        if (p) {
            const badge = btn.querySelector('.progress-badge');
            if (p.status === 'visto') {
                if (badge) badge.textContent = 'Visto ✓';
            } else if (p.status === 'viendo') {
                const mm = Math.floor(p.time / 60), ss = Math.floor(p.time % 60);
                if (badge) badge.textContent = `Continuar ${mm}:${ss.toString().padStart(2,'0')}`;
            }
        }
        btn.addEventListener('click', () => {
            if (!modalState.currentItem) return;
            const opts = { episodeIndex: idx, playlist: episodes };
            if (p && p.status === 'viendo') opts.startTime = p.time || 0;
            if (p && p.status === 'visto') opts.startTime = 0;
            handlePlayAction(modalState.currentItem, opts);
        });
        list.appendChild(li);
    });
    container.innerHTML = '';
    container.appendChild(list);
    setupModalPreview(episodes, modalState.currentItem || {});
}

function updateModalListButton() {
    if (!modalState.listBtn || !modalState.currentItem) return;
    const inList = isInMyList(modalState.currentItem);
    modalState.listBtn.textContent = inList ? 'En mi lista' : '+ Mi lista';
    modalState.listBtn.setAttribute('aria-pressed', inList);
    modalState.listBtn.classList.toggle('in-list', inList);
}

function closeDetailModal() {
    if (!modalState.root) return;
    modalState.closeBtn?.blur();
    modalState.root.classList.remove('show');
    modalState.root.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    if (modalState.previousFocus && typeof modalState.previousFocus.focus === 'function') {
        modalState.previousFocus.focus();
    }
    modalState.previousFocus = null;
    resetModalMedia();
    modalState.currentItem = null;
}

function sanitizeEpisodeList(episodes = []) {
    return episodes.filter(ep => ep && ep.videoPath);
}

function updateHoverPreviewListButton() {
    if (!hoverPreviewState.addBtn || !hoverPreviewState.activeAnime) return;
    const inList = isInMyList(hoverPreviewState.activeAnime);
    hoverPreviewState.addBtn.textContent = inList ? 'En mi lista' : '+ Mi lista';
    hoverPreviewState.addBtn.setAttribute('aria-pressed', inList);
    hoverPreviewState.addBtn.classList.toggle('in-list', inList);
}

async function setupHoverPreview() {
    if (hoverPreviewState.initialized) return;

    const preview = document.getElementById('hover-preview');
    const previewVideo = document.getElementById('hover-video');
    const hoverTitle = document.getElementById('hover-title');
    const previewText = document.getElementById('hover-synopsis');
    const addToListBtn = document.getElementById('add-to-list-btn');
    const playNowBtn = document.getElementById('play-now-btn');
    const volumeToggleBtn = document.getElementById('volume-toggle-btn');

    if (!preview || !previewVideo || !hoverTitle || !previewText || !addToListBtn || !playNowBtn || !volumeToggleBtn) {
        console.warn('setupHoverPreview: elementos del hover preview no encontrados.');
        return;
    }

    hoverPreviewState.initialized = true;
    hoverPreviewState.preview = preview;
    hoverPreviewState.video = previewVideo;
    hoverPreviewState.title = hoverTitle;
    hoverPreviewState.text = previewText;
    hoverPreviewState.addBtn = addToListBtn;
    hoverPreviewState.playBtn = playNowBtn;
    hoverPreviewState.volumeBtn = volumeToggleBtn;

    preview.style.display = 'block';
    hoverPreviewState.dimensions.width = preview.offsetWidth;
    hoverPreviewState.dimensions.height = preview.offsetHeight;
    preview.style.display = 'none';

    if (Array.isArray(movies) && movies.length) {
        hoverPreviewState.mainList = [...movies];
    } else {
        try {
            hoverPreviewState.mainList = await loadAndFixJSON('anime.json');
        } catch (error) {
            console.error('setupHoverPreview: no se pudo cargar anime.json', error);
            hoverPreviewState.mainList = [];
        }
    }

    try {
        const detailData = await ensureDetailData();
        hoverPreviewState.detailList = Array.isArray(detailData)
            ? detailData
            : (detailData?.animesDetail || []);
    } catch (error) {
        console.error('setupHoverPreview: no se pudo cargar el detalle extendido', error);
        hoverPreviewState.detailList = [];
    }

    const state = hoverPreviewState;

    function updateVolumeIcon() {
        state.volumeBtn.textContent = state.isMuted ? '🔈' : '🔊';
    }

    function stopVideo() {
        try { state.video.pause(); } catch (e) { /* ignore */ }
        state.video.removeAttribute('src');
        state.video.style.display = 'none';
    }

    function playCurrentTrailer() {
        if (!state.currentTrailers.length) {
            stopVideo();
            return;
        }

        const src = state.currentTrailers[state.currentIndex] || '';
        if (!src) {
            stopVideo();
            return;
        }

        state.video.preload = 'auto';
        state.video.muted = state.isMuted;
        state.video.volume = 0.5;
        state.video.src = src;
        state.video.style.display = 'block';
        state.video.load();
        state.video.play().catch(err => console.debug('hoverPreview autoplay bloqueado', err));
        updateVolumeIcon();
    }

    function normalizeLinkForMatch(value = '') {
        if (!value) return '';
        try {
            const url = new URL(value, window.location.href);
            value = url.pathname || value;
        } catch (e) { /* ignore */ }
        value = value.split('?')[0].split('#')[0];
        const segments = value.replace(/\\/g, '/').split('/').filter(Boolean);
        return (segments.at(-1) || '').toLowerCase();
    }

    function hidePreview() {
        if (!state.previewVisible) return;
        stopVideo();
        state.preview.style.display = 'none';
        state.currentTrailers = [];
        state.currentIndex = 0;
        state.activeElement = null;
        state.activeAnime = null;
        state.activeEpisodes = [];
        state.previewVisible = false;
        if (typeof startCarousel === 'function') {
            startCarousel();
        }
        if (typeof startHeroRotation === 'function') {
            startHeroRotation();
        }
    }

    function resolveActiveAnime(link, titleText) {
        const normalizedLink = normalizeLinkForMatch(link);
        let target = state.mainList.find(item => normalizeLinkForMatch(item.link) === normalizedLink);
        if (!target && titleText) {
            target = state.mainList.find(item => (item.title || '').toLowerCase() === titleText);
        }
        if (target) return target;
        return {
            title: titleText || 'Sin título',
            synopsis: state.text?.textContent || '',
            short_synopsis: state.text?.textContent || '',
            image: state.video?.poster || '',
            link,
            genres: [],
            type: 'anime'
        };
    }

    function showPreview(item) {
        if (!item) return;
        const link = item.getAttribute('data-link') || '';
        const titleText = (item.querySelector('.carousel-title')?.textContent || '').trim();
        const normalizedLink = normalizeLinkForMatch(link);
        let detailAnime = undefined;
        try {
            detailAnime = state.detailList.find(entry => normalizeLinkForMatch(entry.link) === normalizedLink);
            if (!detailAnime && titleText) {
                detailAnime = state.detailList.find(entry => (entry.title || '').trim().toLowerCase() === titleText.toLowerCase());
            }
        } catch (e) { detailAnime = undefined; }

        state.activeAnime = resolveActiveAnime(link, titleText.toLowerCase());
        state.activeEpisodes = sanitizeEpisodeList(detailAnime?.episodes || []);

        state.title.textContent = titleText || detailAnime?.title || state.activeAnime?.title || 'Sin título';
        state.text.textContent = item.dataset.synopsis || detailAnime?.synopsis || state.activeAnime?.synopsis || 'Sin sinopsis disponible.';

        if (state.activeEpisodes.length) {
            const chosen = state.activeEpisodes[Math.floor(Math.random() * state.activeEpisodes.length)];
            state.currentTrailers = chosen?.videoPath ? [chosen.videoPath] : [];
        } else {
            state.currentTrailers = [];
        }
        state.currentIndex = 0;

        const cardImg = item.querySelector('img');
        if (cardImg?.src) {
            state.video.poster = cardImg.src;
        } else if (state.activeAnime?.image) {
            state.video.poster = state.activeAnime.image;
        } else {
            state.video.removeAttribute('poster');
        }

        if (state.currentTrailers.length) {
            playCurrentTrailer();
            state.video.addEventListener('loadedmetadata', () => {
                try {
                    state.video.currentTime = Math.random() * Math.min(30, state.video.duration || 30);
                } catch (e) { /* ignore */ }
            }, { once: true });
            state.video.addEventListener('canplay', () => {
                state.video.style.display = 'block';
            }, { once: true });
        } else {
            stopVideo();
        }

        const rect = item.getBoundingClientRect();
        let left = rect.right + 10;
        let top = rect.top;
        if (left + state.dimensions.width > window.innerWidth) {
            left = rect.left - state.dimensions.width - 10;
        }
        if (top + state.dimensions.height > window.innerHeight) {
            top = window.innerHeight - state.dimensions.height - 10;
        }

        state.preview.style.left = `${left + window.scrollX}px`;
        state.preview.style.top = `${top + window.scrollY}px`;
        state.preview.style.display = 'block';
        state.previewVisible = true;
        state.activeElement = item;

        updateHoverPreviewListButton();

        if (typeof pauseHeroRotation === 'function') {
            pauseHeroRotation();
        }
        if (typeof pauseCarousel === 'function') {
            try { pauseCarousel(); } catch (error) { console.warn('pauseCarousel falló', error); }
        } else if (typeof carouselInterval !== 'undefined' && carouselInterval) {
            clearInterval(carouselInterval);
            carouselInterval = null;
        }
    }

    state.video.addEventListener('ended', () => {
        if (!state.currentTrailers.length) return;
        state.currentIndex = (state.currentIndex + 1) % state.currentTrailers.length;
        playCurrentTrailer();
    });

    state.volumeBtn.addEventListener('click', () => {
        state.isMuted = !state.isMuted;
        state.video.muted = state.isMuted;
        updateVolumeIcon();
    });
    updateVolumeIcon();

    state.addBtn.addEventListener('click', () => {
        if (!state.activeAnime) return;
        toggleMyList(state.activeAnime);
        updateHoverPreviewListButton();
    });

    state.playBtn.addEventListener('click', () => {
        if (!state.activeAnime) return;
        handlePlayAction(state.activeAnime, { playlist: state.activeEpisodes });
    });

    // Provide controlled open/close API for preview to be used by individual cards
    state.closeTimer = null;
    state.openForElement = (elem) => {
        if (!elem) return;
        // If switching to another card, close previous preview first
        if (state.activeElement && state.activeElement !== elem) {
            hidePreview();
        }
        // cancel any scheduled close and open immediately
        if (state.closeTimer) { clearTimeout(state.closeTimer); state.closeTimer = null; }
        showPreview(elem);
    };

    state.startCloseTimer = () => {
        if (state.closeTimer) clearTimeout(state.closeTimer);
        state.closeTimer = setTimeout(() => {
            hidePreview();
            state.closeTimer = null;
        }, 150);
    };

    state.cancelCloseTimer = () => {
        if (state.closeTimer) { clearTimeout(state.closeTimer); state.closeTimer = null; }
    };

    // Ensure preview is attached to body and can receive pointer events
    try {
        if (state.preview && state.preview.parentElement !== document.body) document.body.appendChild(state.preview);
        if (state.preview) {
            state.preview.style.pointerEvents = 'auto';
            state.preview.style.zIndex = '99999';
        }
    } catch (e) { /* ignore DOM exceptions */ }

    // preview own listeners to allow interaction
    state.preview.addEventListener('mouseenter', () => {
        state.cancelCloseTimer();
    });
    state.preview.addEventListener('mouseleave', () => {
        state.startCloseTimer();
    });

    window.addEventListener('scroll', () => {
        if (state.previewVisible) hidePreview();
    }, { passive: true });
}

function setModalPoster(src, altText = 'Póster del anime') {
    if (!modalState.poster) return;
    if (src) {
        modalState.poster.src = src;
        modalState.poster.alt = altText || 'Vista previa';
        modalState.poster.style.display = 'block';
    } else {
        modalState.poster.removeAttribute('src');
        modalState.poster.style.display = 'none';
    }
}

function resetModalMedia() {
    if (modalState.video) {
        try { modalState.video.pause(); } catch (e) {}
        modalState.video.removeAttribute('src');
        modalState.video.style.display = 'none';
    }
}

function setupModalPreview(episodes = [], item = {}) {
    if (!modalState.video) return;
    const playlist = sanitizeEpisodeList(episodes);
    if (!playlist.length) {
        setModalPoster(item.image, item.title);
        return;
    }
    const first = playlist[0];
    setModalPoster(item.image, item.title);
    modalState.video.src = first.videoPath;
    modalState.video.load();
    modalState.video.style.display = 'block';
    modalState.video.play().catch(() => {});
}

function persistPlayerState(item, playlist, episodeIndex, startTime) {
    const videos = playlist.map(ep => ep.videoPath);
    const titles = playlist.map(ep => ep.title || `Episodio ${ep.episodeNumber || ''}`.trim());
    const selectedVideo = videos[episodeIndex];
    if (!selectedVideo) return false;

    localStorage.setItem('currentVideo', selectedVideo);
    localStorage.setItem('videoTitle', titles[episodeIndex] || item.title || 'Reproducción');
    localStorage.setItem('mainTitle', item.title || 'Anime Zone');
    localStorage.setItem('videoIndex', episodeIndex);
    localStorage.setItem('videoList', JSON.stringify(videos));
    localStorage.setItem('videoTitles', JSON.stringify(titles));
    localStorage.setItem('playerMeta', JSON.stringify({
        poster: item.image || null,
        synopsis: item.short_synopsis || item.synopsis || '',
        type: item.type || '',
    }));
    // store requested resume start time (if provided). Keep existing value if not provided.
    if (typeof startTime !== 'undefined' && startTime !== null) {
        try { localStorage.setItem('currentTime', String(Math.floor(Number(startTime) || 0))); } catch (e) {}
    }
    return true;
}

function toggleLoadingOverlay(show = false) {
    const overlay = document.getElementById('loading-overlay');
    if (!overlay) return;
    overlay.classList.toggle('show', Boolean(show));
    overlay.setAttribute('aria-hidden', show ? 'false' : 'true');
}

function resetOverlay() {
    const overlay = document.getElementById('loading-overlay');
    if (!overlay) return;
    overlay.classList.remove('show');
    overlay.setAttribute('aria-hidden', 'true');
}

async function handlePlayAction(item = {}, options = {}) {
    if (!item) return;
    try {
        toggleLoadingOverlay(true);
        const playlist = await resolvePlaylist(item, options);
        if (!playlist.length) {
            toggleLoadingOverlay(false);
            if (item.link) window.location.href = item.link;
            return;
        }
        const episodeIndex = Math.max(0, Math.min(options.episodeIndex ?? 0, playlist.length - 1));
        const ok = persistPlayerState(item, playlist, episodeIndex, options.startTime);
        if (!ok) {
            toggleLoadingOverlay(false);
            if (item.link) window.location.href = item.link;
            return;
        }
        setTimeout(() => { window.location.href = PLAYER_PATH; }, 120);
    } catch (error) {
        console.error('No se pudo iniciar la reproducción', error);
        toggleLoadingOverlay(false);
    }
}

async function resolvePlaylist(item = {}, options = {}) {
    const provided = sanitizeEpisodeList(options?.playlist);
    if (provided.length) return provided;

    const linkKey = normalizeLinkKey(item.link || item.title || '');
    const cached = detailCache.get(linkKey);
    if (cached?.episodes?.length) return sanitizeEpisodeList(cached.episodes);

    const detailData = await ensureDetailData();
    const extra = detailData.find(entry => normalizeLinkKey(entry.link) === linkKey);
    if (extra?.episodes?.length) {
        detailCache.set(linkKey, extra);
        return sanitizeEpisodeList(extra.episodes);
    }
    return [];
}


// =========================
// MOSTRAR CONTENIDO PRINCIPAL
// =========================
function displayMainContent() {
    setupSearch();

    const shuffledMovies = shuffleArray([...movies]);
    const carouselItems = Array.isArray(shuffledMovies) ? shuffledMovies.slice(0, MAX_CAROUSEL_ITEMS) : [];
    // initialize hover preview first so card-level listeners can call its API
    setupHoverPreview();
    prepareInfiniteCarousel(carouselItems, document.getElementById('carousel'));
    startCarousel();
    setupCarouselHoverPause();
    bindNavEvents();
}

// =========================
// MOSTRAR PELÍCULAS COMPLETAS
// =========================
function displayMovies(movieList, container) {
    console.warn('displayMovies quedó como helper legacy; usa applyFiltersAndRender en su lugar.', movieList, container);
}

// =========================
// CONFIGURAR BÚSQUEDA
// =========================
function setupSearch() {
    const searchInput = document.getElementById('search-bar');
    if (!searchInput) return console.error("No se encontró el campo de búsqueda.");
    searchInput.addEventListener('keyup', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(searchMovies, 300);
    });
}

function searchMovies() {
    const searchInput = document.getElementById('search-bar');
    if (!searchInput) return;
    currentSearchTerm = searchInput.value.trim().toLowerCase();
    currentPage = 1;
    applyFiltersAndRender();
}

// =========================
// CARRUSEL INFINITO
// =========================
function prepareInfiniteCarousel(shuffledMovies, container) {
    if (!container) return console.error("Contenedor de carrusel no encontrado");
    if (carouselInitialized) return; // initialize carousel only once
    container.innerHTML = '';

    // Limit number of items rendered into the carousel to avoid large DOM
    const limited = Array.isArray(shuffledMovies) ? shuffledMovies.slice(0, MAX_CAROUSEL_ITEMS) : [];
    // Clonar inicio y final para efecto infinito
    limited.slice(-itemsPerPage).forEach(movie => createCarouselItem(movie, container));
    limited.forEach(movie => createCarouselItem(movie, container));
    limited.slice(0, itemsPerPage).forEach(movie => createCarouselItem(movie, container));

    setTimeout(() => {
        const carousel = document.querySelector('.carousel');
        const firstItem = document.querySelector('.carousel-item');
        if (!carousel || !firstItem) return;
        const itemWidth = getItemWidth();
        // start showing the real items centered by moving to itemsPerPage offset
        currentIndex = itemsPerPage;
        carousel.style.transition = 'none';
        carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
    }, 100);
}

function createCarouselItem(movie, container) {
    const carouselItem = document.createElement('div');
    carouselItem.classList.add('carousel-item');

    // make item keyboard-focusable and accessible
    carouselItem.setAttribute('tabindex', '0');
    carouselItem.setAttribute('role', 'button');
    carouselItem.setAttribute('aria-label', movie.title || 'Ver detalle');

    carouselItem.setAttribute('data-trailers', JSON.stringify(movie.trailer || []));
    carouselItem.dataset.synopsis = movie.synopsis || 'Sin sinopsis disponible.';
    carouselItem.setAttribute('data-link', movie.link);

    const inList = isInMyList(movie);
    const linkKey = normalizeLinkKey(movie.link || movie.title || crypto.randomUUID?.() || String(Date.now()));
    carouselItem.dataset.linkKey = linkKey;

    carouselItem.innerHTML = `
        <div class="carousel-card ${inList ? 'in-list' : ''}">
            <a href="${movie.link}" class="carousel-link" tabindex="-1" aria-hidden="true">
                <img src="${movie.image}" alt="${movie.title}" loading="lazy" decoding="async">
                <div class="carousel-overlay">
                    <div class="carousel-title">${movie.title || ''}</div>
                    <div class="carousel-actions">
                        <button type="button" data-action="play">▶</button>
                        <button type="button" data-action="info">ℹ️</button>
                        <button type="button" data-action="list" aria-pressed="${inList}">${inList ? '✓' : '+'}</button>
                    </div>
                </div>
            </a>
        </div>
    `;

    const playBtn = carouselItem.querySelector('[data-action="play"]');
    const infoBtn = carouselItem.querySelector('[data-action="info"]');
    const listBtn = carouselItem.querySelector('[data-action="list"]');

    playBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        handlePlayAction(movie);
    });

    infoBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        openDetailModal(movie);
    });

    listBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        toggleMyList(movie);
    });

    // card-level hover handlers (mouseenter/mouseleave) to control preview lifecycle
    try {
        carouselItem.addEventListener('mouseenter', () => {
            try { if (hoverPreviewState?.openForElement) hoverPreviewState.openForElement(carouselItem); } catch (e) {}
        });
        carouselItem.addEventListener('mouseleave', () => {
            try { if (hoverPreviewState?.startCloseTimer) hoverPreviewState.startCloseTimer(); } catch (e) {}
        });
    } catch (e) { /* ignore if DOM not ready */ }

    container.appendChild(carouselItem);
}

function moveCarousel(direction) {
    if (isAnimating) return;
    isAnimating = true;

    const carousel = document.querySelector('.carousel');
    const firstItem = document.querySelector('.carousel-item');
    if (!carousel || !firstItem) return;

    const itemWidth = getItemWidth();
    currentIndex += direction;
    carousel.style.transition = "transform 0.5s ease-in-out";
    carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;

    setTimeout(() => {
        const items = document.querySelectorAll('.carousel-item');

        if (currentIndex >= items.length - itemsPerPage) {
            carousel.style.transition = "none";
            currentIndex = itemsPerPage;
            carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
            carousel.offsetHeight;
        } else if (currentIndex <= 0) {
            carousel.style.transition = "none";
            currentIndex = items.length - (2 * itemsPerPage);
            carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
            carousel.offsetHeight;
        }
        isAnimating = false;
    }, 500);
}

function startCarousel() {
    if (carouselInterval) clearInterval(carouselInterval);
    carouselInterval = setInterval(() => moveCarousel(1), 5000);
    // expose to window so other scripts (like hover preview) can pause/resume the carousel
    try { window.carouselInterval = carouselInterval; } catch (e) { /* ignore */ }
}

function setupCarouselHoverPause() {
    const carousel = document.querySelector('.carousel');
    if (!carousel) return;

    carousel.addEventListener('mouseenter', () => {
        if (carouselInterval) { clearInterval(carouselInterval); carouselInterval = null; }
        try { window.carouselInterval = null; } catch (e) {}
    });

    carousel.addEventListener('mouseleave', () => {
        startCarousel();
    });
}

// =========================
// UTILIDADES
// =========================
function shuffleArray(array) {
    return array.sort(() => Math.random() - 0.5);
}

function setupFiltersAndView(animeList = [], movieList = []) {
    allCatalogItems = [...animeList, ...movieList].filter(Boolean);
    buildGenreChips(allCatalogItems);
    applyFiltersAndRender();
    initDetailModal();
}

function buildGenreChips(data) {
    const genresContainer = document.getElementById('genres-container');
    const tagsWrapper = document.getElementById('tags-container');
    if (!genresContainer) return;
    const genreSet = new Set();
    data.forEach(item => (item.genres || []).forEach(g => genreSet.add(g)));
    genresContainer.innerHTML = '';
    genreSet.forEach(genre => {
        const chip = document.createElement('button');
        chip.className = 'tag-btn';
        chip.type = 'button';
        chip.textContent = genre;
        chip.addEventListener('click', () => toggleGenreFilter(genre, chip));
        genresContainer.appendChild(chip);
    });
    if (tagsWrapper) {
        tagsWrapper.classList.toggle('has-content', genreSet.size > 0);
    }
}

function toggleGenreFilter(genre, chip) {
    const isActive = activeGenres.has(genre);
    if (isActive) {
        activeGenres.delete(genre);
        chip.classList.remove('active');
    } else {
        activeGenres.add(genre);
        chip.classList.add('active');
    }
    currentPage = 1;
    applyFiltersAndRender();
}

function applyFiltersAndRender() {
    const movieContainer = document.getElementById('movie-container');
    const gridContainer = document.getElementById('movie-grid');
    const activeFilterBadge = document.getElementById('active-filter');
    if (!movieContainer) return;

    let listToRender = [...allCatalogItems];
    if (currentTypeFilter) {
        listToRender = listToRender.filter(item => (item.type || 'anime').toLowerCase() === currentTypeFilter);
    }
    if (activeGenres.size) {
        listToRender = listToRender.filter(item => item.genres?.some(g => activeGenres.has(g)));
    }
    if (currentSearchTerm) {
        listToRender = listToRender.filter(item => (item.title || '').toLowerCase().includes(currentSearchTerm));
    }
    if (currentView === 'mylist') {
        listToRender = listToRender.filter(item => isInMyList(item));
    }

    // store filtered list and compute pagination
    filteredList = listToRender;
    totalPages = Math.max(1, Math.ceil(filteredList.length / PAGE_SIZE));
    if (currentPage > totalPages) currentPage = totalPages;

    const start = (currentPage - 1) * PAGE_SIZE;
    const pageItems = filteredList.slice(start, start + PAGE_SIZE);

    movieContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();
    pageItems.forEach(item => fragment.appendChild(createStandardMovieCard(item)));
    movieContainer.appendChild(fragment);

    renderPaginationControls();

    if (gridContainer && currentView !== 'peliculas') {
        gridContainer.style.display = 'none';
    }
    if (activeFilterBadge) {
        const parts = [];
        if (currentView === 'mylist') parts.push('Mi lista');
        if (currentTypeFilter) parts.push(`Tipo: ${capitalize(currentTypeFilter)}`);
        if (activeGenres.size) parts.push(`Géneros: ${Array.from(activeGenres).join(', ')}`);
        if (currentSearchTerm) parts.push(`Búsqueda: ${currentSearchTerm}`);
        activeFilterBadge.textContent = parts.length ? parts.join(' · ') : '';
        activeFilterBadge.style.display = parts.length ? 'block' : 'none';
    }
}

function renderPaginationControls() {
    const pagination = document.getElementById('pagination');
    if (!pagination) return;
    pagination.innerHTML = '';

    const createButton = (label, cls, disabled, onClick) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = cls || '';
        btn.textContent = label;
        if (disabled) btn.disabled = true;
        if (onClick) btn.addEventListener('click', onClick);
        return btn;
    };

    // previous
    pagination.appendChild(createButton('←', 'page-prev', currentPage <= 1, () => {
        if (currentPage > 1) { currentPage--; applyFiltersAndRender(); document.getElementById('movie-container')?.scrollIntoView({ behavior: 'smooth' }); }
    }));

    // pages around current (±2)
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);
    if (startPage > 1) {
        pagination.appendChild(createButton('1', '', false, () => { currentPage = 1; applyFiltersAndRender(); document.getElementById('movie-container')?.scrollIntoView({ behavior: 'smooth' }); }));
        if (startPage > 2) {
            const dots = document.createElement('span'); dots.className = 'page-dots'; dots.textContent = '…'; pagination.appendChild(dots);
        }
    }

    for (let p = startPage; p <= endPage; p++) {
        const isActive = p === currentPage;
        const btn = createButton(p.toString(), isActive ? 'page-number active' : 'page-number', false, () => { currentPage = p; applyFiltersAndRender(); document.getElementById('movie-container')?.scrollIntoView({ behavior: 'smooth' }); });
        if (isActive) btn.setAttribute('aria-current', 'page');
        pagination.appendChild(btn);
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            const dots = document.createElement('span'); dots.className = 'page-dots'; dots.textContent = '…'; pagination.appendChild(dots);
        }
        pagination.appendChild(createButton(totalPages.toString(), '', false, () => { currentPage = totalPages; applyFiltersAndRender(); document.getElementById('movie-container')?.scrollIntoView({ behavior: 'smooth' }); }));
    }

    // next
    pagination.appendChild(createButton('→', 'page-next', currentPage >= totalPages, () => {
        if (currentPage < totalPages) { currentPage++; applyFiltersAndRender(); document.getElementById('movie-container')?.scrollIntoView({ behavior: 'smooth' }); }
    }));
}

function bindNavEvents() {
    if (navEventsBound) return;
    const navInicio = document.getElementById('nav-inicio');
    const navSeries = document.getElementById('nav-series');
    const navPeliculas = document.getElementById('nav-peliculas');
    const navMyList = document.getElementById('nav-mylist');

    navInicio?.addEventListener('click', (ev) => {
        ev.preventDefault();
        currentTypeFilter = 'anime';
        currentView = 'catalog';
        showMainCatalogSection();
        currentPage = 1;
        applyFiltersAndRender();
    });

    navSeries?.addEventListener('click', (ev) => {
        ev.preventDefault();
        currentTypeFilter = 'serie';
        currentView = 'catalog';
        showMainCatalogSection();
        currentPage = 1;
        applyFiltersAndRender();
    });

    navPeliculas?.addEventListener('click', (ev) => {
        ev.preventDefault();
        currentTypeFilter = 'pelicula';
        currentView = 'peliculas';
        currentPage = 1;
        showStandaloneMoviesSection();
    });

    navMyList?.addEventListener('click', (ev) => {
        ev.preventDefault();
        currentView = currentView === 'mylist' ? 'catalog' : 'mylist';
        showMainCatalogSection();
        currentPage = 1;
        applyFiltersAndRender();
    });

    navEventsBound = true;
}

function showMainCatalogSection() {
    const grid = document.getElementById('movie-grid');
    const container = document.getElementById('movie-container');
    if (grid) grid.style.display = 'none';
    if (container) {
        container.classList.add('movies');
        container.style.display = '';
    }
}

function showStandaloneMoviesSection() {
    const grid = document.getElementById('movie-grid');
    const container = document.getElementById('movie-container');
    const activeFilterBadge = document.getElementById('active-filter');
    if (container) container.style.display = 'none';

    if (!standaloneMovies.length && allCatalogItems.length) {
        standaloneMovies = allCatalogItems.filter(item => (item.type || '').toLowerCase() === 'pelicula');
    }

    if (grid) {
        if (!grid.childElementCount) {
            renderStandaloneMovieGrid(standaloneMovies, grid);
        }
        grid.style.display = 'grid';
        grid.scrollIntoView({ behavior: 'smooth' });
    }

    if (activeFilterBadge) {
        activeFilterBadge.textContent = 'Películas';
        activeFilterBadge.style.display = 'block';
    }
}

async function loadAdditionalLibrary(path) {
    try {
        const data = await loadAndFixJSON(path);
        if (Array.isArray(data) && data.length) return data;
        const res = await fetch(path);
        return await res.json();
    } catch (error) {
        console.error(`No se pudo cargar ${path}`, error);
        return [];
    }
}

function setupHeroSection(animeList = [], movieList = []) {
    const heroSection = document.getElementById('hero');
    if (!heroSection) return;

    heroQueue = [...animeList, ...movieList].filter(Boolean);
    if (!heroQueue.length) {
        heroSection.style.display = 'none';
        return;
    }

    heroIndex = 0;
    renderHeroItem(heroQueue[heroIndex]);
    wireHeroButtons();
    startHeroRotation();
}

function wireHeroButtons() {
    if (heroActionsBound) return;
    const heroPlay = document.getElementById('hero-play');
    const heroInfo = document.getElementById('hero-info');
    const heroAdd = document.getElementById('hero-add');
    const heroSection = document.getElementById('hero');
    if (!heroPlay || !heroInfo || !heroSection || !heroAdd) return;

    heroInfo.addEventListener('click', (ev) => {
        ev.preventDefault();
        const currentItem = heroQueue[heroIndex];
        if (currentItem) openDetailModal(currentItem);
    });

    heroPlay.addEventListener('click', (ev) => {
        ev.preventDefault();
        const currentItem = heroQueue[heroIndex];
        if (currentItem) handlePlayAction(currentItem);
    });

    heroAdd.addEventListener('click', () => {
        const currentItem = heroQueue[heroIndex];
        if (currentItem) toggleMyList(currentItem);
    });

    heroSection.addEventListener('mouseenter', pauseHeroRotation);
    heroSection.addEventListener('mouseleave', startHeroRotation);
    heroActionsBound = true;
}

function renderHeroItem(item = {}) {
    if (hoverPreviewState.previewVisible) return;
    const heroTitle = document.getElementById('hero-title');
    const heroDesc = document.getElementById('hero-description');
    const heroTags = document.getElementById('hero-tags');
    const heroRating = document.getElementById('hero-rating');
    const heroBackdrop = document.getElementById('hero-backdrop');
    const heroPlay = document.getElementById('hero-play');

    if (!heroTitle || !heroDesc || !heroTags || !heroRating || !heroBackdrop || !heroPlay) return;

    heroTitle.textContent = item.title || 'Título no disponible';
    heroDesc.textContent = item.short_synopsis || item.synopsis || 'Sin sinopsis disponible.';
    heroTags.textContent = formatHeroTags(item);
    heroRating.textContent = formatHeroMeta(item);
    if (item.image) {
        heroBackdrop.style.backgroundImage = `url('${item.image}')`;
    }
    heroPlay.href = item.link || '#';
    updateHeroMyListButton(item);
}

function startHeroRotation() {
    if (!heroQueue.length) return;
    pauseHeroRotation();
    heroIntervalId = setInterval(() => {
        heroIndex = (heroIndex + 1) % heroQueue.length;
        renderHeroItem(heroQueue[heroIndex]);
    }, HERO_ROTATION_MS);
}

function pauseHeroRotation() {
    if (heroIntervalId) {
        clearInterval(heroIntervalId);
        heroIntervalId = null;
    }
}

function formatHeroTags(item) {
    if (Array.isArray(item.genres) && item.genres.length) {
        return item.genres.slice(0, 3).join(' · ');
    }
    return 'Sin género definido';
}

function formatHeroMeta(item) {
    const typeLabel = (item.type || 'anime').toString().replace(/_/g, ' ');
    const idioma = item.idioma || 'Idioma no disponible';
    const totalVideos = item.num_videos ? `· ${item.num_videos} ${item.num_videos === 1 ? 'video' : 'videos'}` : '';
    return `${capitalize(typeLabel)} · ${idioma} ${totalVideos}`.trim();
}

function capitalize(str = '') {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function initMyList() {
    try {
        const stored = JSON.parse(localStorage.getItem(MY_LIST_STORAGE_KEY) || '[]');
        myListMap = new Map(
            (stored || []).filter(item => item?.link).map(item => [normalizeLinkKey(item.link), item])
        );
    } catch (error) {
        console.warn('No se pudo leer Mi lista', error);
        myListMap = new Map();
    }
}

function persistMyList() {
    try {
        const serialized = Array.from(myListMap.values());
        localStorage.setItem(MY_LIST_STORAGE_KEY, JSON.stringify(serialized));
    } catch (error) {
        console.warn('No se pudo guardar Mi lista', error);
    }
}

function toggleMyList(item) {
    if (!item || !item.link) return;
    const key = normalizeLinkKey(item.link);
    if (myListMap.has(key)) {
        myListMap.delete(key);
    } else {
        myListMap.set(key, item);
    }
    persistMyList();
    refreshCardsForLink(key);
    updateHeroMyListButton(heroQueue[heroIndex]);
    updateHoverPreviewListButton();
}

function refreshCardsForLink(linkKey) {
    const inList = myListMap.has(linkKey);
    document.querySelectorAll(`[data-link-key="${linkKey}"]`).forEach(card => {
        card.classList.toggle('in-list', inList);
        const listBtn = card.querySelector('[data-action="list"]');
        if (listBtn) {
            listBtn.textContent = inList ? '✓' : '+';
            listBtn.setAttribute('aria-pressed', inList);
            listBtn.setAttribute('aria-label', inList ? 'Quitar de Mi lista' : 'Agregar a Mi lista');
        }
    });
}

function updateHeroMyListButton(item) {
    const heroAdd = document.getElementById('hero-add');
    if (!heroAdd || !item) return;
    const inList = isInMyList(item);
    const addLabel = heroAdd.dataset.mylistLabelAdd || '+ Mi lista';
    const removeLabel = heroAdd.dataset.mylistLabelRemove || 'En mi lista';
    heroAdd.textContent = inList ? removeLabel : addLabel;
    heroAdd.setAttribute('aria-pressed', inList);
    heroAdd.classList.toggle('in-list', inList);
}

function isInMyList(item) {
    if (!item?.link) return false;
    return myListMap.has(normalizeLinkKey(item.link));
}

function normalizeLinkKey(link = '') {
    return link.toString().trim().replace(/\\/g, '/');
}

function getBanderaByIdioma(idioma) {
    switch ((idioma || '').toString()) {
        case 'Japonés':
            return 'jp.png';
        case 'Español Latino':
            return 'lt.png';
        case 'Chino':
            return 'cn.png';
        default:
            return '2B.png';
    }
}

function createStandardMovieCard(movie) {
    const card = document.createElement('article');
    card.className = 'movie-card premium';
    const linkKey = normalizeLinkKey(movie.link || movie.title || crypto.randomUUID?.() || String(Date.now()));
    card.dataset.linkKey = linkKey;

    const inList = isInMyList(movie);
    if (inList) card.classList.add('in-list');

    const genres = (movie.genres || []).slice(0, 3).map(tag => `<span>${tag}</span>`).join('');
    const idiomaPill = movie.idioma ? `<span class="card-meta-pill">${movie.idioma}</span>` : '';
    const typePill = movie.type ? `<span class="card-meta-pill">${capitalize(movie.type)}</span>` : '';
    const accentBadge = movie.type === 'pelicula' ? 'PELÍCULA' : (movie.type ? movie.type.toUpperCase() : 'ANIME');

    card.innerHTML = `
        <div class="card-media">
            <a class="card-link" href="${movie.link || '#'}" aria-label="Abrir ${movie.title || 'detalle'}">
                <img src="${movie.image || ''}" alt="${movie.title || ''}" loading="lazy" decoding="async">
            </a>
            <div class="card-gradient"></div>
            <div class="card-badges">
                <span class="card-badge">${accentBadge}</span>
                ${movie.idioma ? `<span class="card-badge subtle">${movie.idioma}</span>` : ''}
            </div>
            <div class="card-quick-actions">
                <button type="button" data-action="play" aria-label="Reproducir ${movie.title || ''}">▶</button>
                <button type="button" data-action="info" aria-label="Ver información de ${movie.title || ''}">ℹ️</button>
                <button type="button" data-action="list" aria-pressed="${inList}" aria-label="${inList ? 'Quitar de Mi lista' : 'Agregar a Mi lista'}">${inList ? '✓' : '+'}</button>
            </div>
        </div>
        <div class="card-info">
            <h3 class="card-title">${movie.title || ''}</h3>
            <div class="card-meta">${idiomaPill}${typePill}</div>
            <p class="card-synopsis">${movie.short_synopsis || movie.synopsis || 'Sinopsis no disponible.'}</p>
            <div class="card-tags">${genres}</div>
        </div>
    `;

    const playBtn = card.querySelector('[data-action="play"]');
    const infoBtn = card.querySelector('[data-action="info"]');
    const listBtn = card.querySelector('[data-action="list"]');

    playBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        handlePlayAction(movie);
    });

    infoBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        openDetailModal(movie);
    });

    listBtn?.addEventListener('click', (ev) => {
        ev.preventDefault();
        toggleMyList(movie);
    });

    return card;
}

// Exponer helpers para que otros módulos reutilicen la misma tarjeta/flags
try {
    window.createStandardMovieCard = createStandardMovieCard;
    window.getBanderaByIdioma = getBanderaByIdioma;
    window.handlePlayAction = handlePlayAction;
} catch (e) {
    console.warn('No se pudieron exponer los helpers globales', e);
}

function getItemWidth() {
    const firstItem = document.querySelector('.carousel-item');
    const carousel = document.querySelector('.carousel');
    if (!firstItem) return 235;
    // prefer gap from carousel if available (flex gap), otherwise fall back to marginRight
    let gap = 16;
    if (carousel) {
        const cStyle = window.getComputedStyle(carousel);
        const g = cStyle.gap || cStyle.getPropertyValue('gap');
        if (g) gap = parseFloat(g);
    }
    const style = window.getComputedStyle(firstItem);
    const marginRight = parseFloat(style.marginRight) || 0;
    // use the larger of computed gap or marginRight to be safe
    const usedGap = Math.max(gap, marginRight);
    return firstItem.offsetWidth + usedGap;
}

// =========================
// INICIALIZACIÓN
// =========================
document.addEventListener("DOMContentLoaded", () => {
    console.log('Iniciando carga...');
    resetOverlay();
    window.addEventListener('pageshow', resetOverlay);
    loadMovies();
    // header shrink behavior: compact header when scrolling or interacting with carousel
    const headerEl = document.querySelector('header');
    const carouselEl = document.querySelector('.carousel');
    const SCROLL_SHRINK_PX = 60;
    function updateHeaderShrink() {
        if (!headerEl) return;
        if (window.scrollY > SCROLL_SHRINK_PX) headerEl.classList.add('shrink');
        else headerEl.classList.remove('shrink');
    }
    window.addEventListener('scroll', updateHeaderShrink, { passive: true });
    // shrink while interacting with carousel to give more vertical space
    if (carouselEl) {
        carouselEl.addEventListener('mouseenter', () => { headerEl && headerEl.classList.add('shrink'); });
        carouselEl.addEventListener('mouseleave', () => { if (window.scrollY <= SCROLL_SHRINK_PX) headerEl && headerEl.classList.remove('shrink'); });
    }

});
