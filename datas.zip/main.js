// =========================
// VARIABLES GLOBALES
// =========================
let movies = [];
let currentIndex = 1;
const itemsPerPage = 5;
let isAnimating = false;
let searchTimeout = null;
let carouselInterval = null;

// =========================
// CARGAR PELÍCULAS DESDE JSON
// =========================
async function loadMovies() {
    const loadingMessage = document.getElementById('loading-message');
    try {
        if (loadingMessage) loadingMessage.style.display = 'block';

        // Antes: fetch('anime.json')
        // Ahora: usamos fixPaths.js
        movies = await window.loadAndFixJSON('anime.json');

        console.log('Datos cargados y rutas corregidas:', movies);

        // Mostrar todas las películas en el contenedor
        const movieContainer = document.getElementById('movie-container');
        if (movieContainer) displayMovies(movies, movieContainer);

        // Inicializar carrusel y búsqueda
        displayMainContent();
    } catch (error) {
        console.error('Error cargando datos:', error);
        if (loadingMessage) {
            loadingMessage.innerText = 'Error al cargar los datos';
            loadingMessage.style.color = 'red';
        }
    } finally {
        if (loadingMessage) loadingMessage.style.display = 'none';
    }
}


// =========================
// MOSTRAR CONTENIDO PRINCIPAL
// =========================
function displayMainContent() {
    setupSearch();

    const shuffledMovies = shuffleArray([...movies]);
    prepareInfiniteCarousel(shuffledMovies, document.getElementById('carousel'));
    setupHoverPreview?.(); // si tienes preview de hover
    startCarousel();
    setupCarouselHoverPause();
}

// =========================
// MOSTRAR PELÍCULAS COMPLETAS
// =========================
function displayMovies(movieList, container) {
    if (!container) return console.error('Contenedor de películas no encontrado');
    container.innerHTML = '';

    if (movieList.length === 0) {
        container.innerHTML = '<p class="no-results">No se encontraron resultados</p>';
        return;
    }

    const fragment = document.createDocumentFragment();
    movieList.forEach(movie => {
        fragment.appendChild(createStandardMovieCard(movie));
    });
    container.appendChild(fragment);
}

// =========================
// CONFIGURAR BÚSQUEDA
// =========================
function setupSearch() {
    const searchInput = document.getElementById('search-bar');
    if (!searchInput) return console.error("No se encontró el campo de búsqueda.");
    searchInput.addEventListener('keyup', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(searchMovies, 300);
    });
}

function searchMovies() {
    const searchInput = document.getElementById('search-bar');
    const movieContainer = document.getElementById('movie-container');
    const noResultsMessage = document.getElementById('no-results-message');
    if (!searchInput || !movieContainer) return;

    const searchTerm = searchInput.value.trim().toLowerCase();
    const filteredMovies = movies.filter(movie =>
        movie.title.toLowerCase().includes(searchTerm)
    );

    displayMovies(filteredMovies, movieContainer);
    if (noResultsMessage) {
        noResultsMessage.style.display = filteredMovies.length === 0 ? 'block' : 'none';
    }
}

// =========================
// CARRUSEL INFINITO
// =========================
function prepareInfiniteCarousel(shuffledMovies, container) {
    if (!container) return console.error("Contenedor de carrusel no encontrado");
    container.innerHTML = '';

    // Clonar inicio y final para efecto infinito
    shuffledMovies.slice(-itemsPerPage).forEach(movie => createCarouselItem(movie, container));
    shuffledMovies.forEach(movie => createCarouselItem(movie, container));
    shuffledMovies.slice(0, itemsPerPage).forEach(movie => createCarouselItem(movie, container));

    setTimeout(() => {
        const carousel = document.querySelector('.carousel');
        const firstItem = document.querySelector('.carousel-item');
        if (!carousel || !firstItem) return;
        const itemWidth = getItemWidth();
        // start showing the real items centered by moving to itemsPerPage offset
        currentIndex = itemsPerPage;
        carousel.style.transition = 'none';
        carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
    }, 100);
}

function createCarouselItem(movie, container) {
    const carouselItem = document.createElement('div');
    carouselItem.classList.add('carousel-item');

    // make item keyboard-focusable and accessible
    carouselItem.setAttribute('tabindex', '0');
    carouselItem.setAttribute('role', 'button');
    carouselItem.setAttribute('aria-label', movie.title || 'Ver detalle');

    carouselItem.setAttribute('data-trailers', JSON.stringify(movie.trailer || []));
    carouselItem.dataset.synopsis = movie.synopsis || 'Sin sinopsis disponible.';
    carouselItem.setAttribute('data-link', movie.link);

    carouselItem.innerHTML = `
      <a href="${movie.link}" class="carousel-link" tabindex="-1" aria-hidden="true">
          <img src="${movie.image}" alt="${movie.title}" loading="lazy">
          <div class="carousel-info">
              <h3 class="carousel-title">${movie.title}</h3>
          </div>
      </a>
   `;

    container.appendChild(carouselItem);
}

function moveCarousel(direction) {
    if (isAnimating) return;
    isAnimating = true;

    const carousel = document.querySelector('.carousel');
    const firstItem = document.querySelector('.carousel-item');
    if (!carousel || !firstItem) return;

    const itemWidth = getItemWidth();
    currentIndex += direction;
    carousel.style.transition = "transform 0.5s ease-in-out";
    carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;

    setTimeout(() => {
        const items = document.querySelectorAll('.carousel-item');

        if (currentIndex >= items.length - itemsPerPage) {
            carousel.style.transition = "none";
            currentIndex = itemsPerPage;
            carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
            carousel.offsetHeight;
        } else if (currentIndex <= 0) {
            carousel.style.transition = "none";
            currentIndex = items.length - (2 * itemsPerPage);
            carousel.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
            carousel.offsetHeight;
        }
        isAnimating = false;
    }, 500);
}

function startCarousel() {
    if (carouselInterval) clearInterval(carouselInterval);
    carouselInterval = setInterval(() => moveCarousel(1), 5000);
    // expose to window so other scripts (like hover preview) can pause/resume the carousel
    try { window.carouselInterval = carouselInterval; } catch (e) { /* ignore */ }
}

function setupCarouselHoverPause() {
    const carousel = document.querySelector('.carousel');
    if (!carousel) return;

    carousel.addEventListener('mouseenter', () => {
        if (carouselInterval) { clearInterval(carouselInterval); carouselInterval = null; }
        try { window.carouselInterval = null; } catch (e) {}
    });

    carousel.addEventListener('mouseleave', () => {
        startCarousel();
    });
}

// =========================
// UTILIDADES
// =========================
function shuffleArray(array) {
    return array.sort(() => Math.random() - 0.5);
}

function getBanderaByIdioma(idioma) {
    switch ((idioma || '').toString()) {
        case 'Japonés':
            return 'jp.png';
        case 'Español Latino':
            return 'lt.png';
        case 'Chino':
            return 'cn.png';
        default:
            return '2B.png';
    }
}

function createStandardMovieCard(movie) {
    const card = document.createElement('div');
    card.className = 'movie movie-card';

    const link = document.createElement('a');
    link.className = 'movie-link';
    link.href = movie.link || '#';
    link.setAttribute('aria-label', movie.title || 'Ver detalle');

    const imageContainer = document.createElement('div');
    imageContainer.className = 'image-container';

    const img = document.createElement('img');
    img.src = movie.image || '';
    img.alt = movie.title || '';
    img.loading = 'lazy';
    imageContainer.appendChild(img);

    const flag = getBanderaByIdioma(movie.idioma);
    if (flag) {
        const flagImg = document.createElement('img');
        flagImg.src = `media/icons/${flag}`;
        flagImg.alt = movie.idioma || '';
        flagImg.title = movie.idioma || '';
        flagImg.className = 'idioma-icono';
        imageContainer.appendChild(flagImg);
    }

    const info = document.createElement('div');
    info.className = 'movie-info';
    const title = document.createElement('h3');
    title.textContent = movie.title || '';
    info.appendChild(title);

    link.appendChild(imageContainer);
    link.appendChild(info);
    card.appendChild(link);

    return card;
}

// Exponer helpers para que otros módulos reutilicen la misma tarjeta/flags
try {
    window.createStandardMovieCard = createStandardMovieCard;
    window.getBanderaByIdioma = getBanderaByIdioma;
} catch (e) {
    console.warn('No se pudieron exponer los helpers globales', e);
}

function getItemWidth() {
    const firstItem = document.querySelector('.carousel-item');
    const carousel = document.querySelector('.carousel');
    if (!firstItem) return 235;
    // prefer gap from carousel if available (flex gap), otherwise fall back to marginRight
    let gap = 16;
    if (carousel) {
        const cStyle = window.getComputedStyle(carousel);
        const g = cStyle.gap || cStyle.getPropertyValue('gap');
        if (g) gap = parseFloat(g);
    }
    const style = window.getComputedStyle(firstItem);
    const marginRight = parseFloat(style.marginRight) || 0;
    // use the larger of computed gap or marginRight to be safe
    const usedGap = Math.max(gap, marginRight);
    return firstItem.offsetWidth + usedGap;
}

// =========================
// INICIALIZACIÓN
// =========================
document.addEventListener("DOMContentLoaded", () => {
    console.log('Iniciando carga...');
    loadMovies();
    // header shrink behavior: compact header when scrolling or interacting with carousel
    const headerEl = document.querySelector('header');
    const carouselEl = document.querySelector('.carousel');
    const SCROLL_SHRINK_PX = 60;
    function updateHeaderShrink() {
        if (!headerEl) return;
        if (window.scrollY > SCROLL_SHRINK_PX) headerEl.classList.add('shrink');
        else headerEl.classList.remove('shrink');
    }
    window.addEventListener('scroll', updateHeaderShrink, { passive: true });
    // shrink while interacting with carousel to give more vertical space
    if (carouselEl) {
        carouselEl.addEventListener('mouseenter', () => { headerEl && headerEl.classList.add('shrink'); });
        carouselEl.addEventListener('mouseleave', () => { if (window.scrollY <= SCROLL_SHRINK_PX) headerEl && headerEl.classList.remove('shrink'); });
    }

    // Nav: Películas should load `movies.json` into the movie grid without breaking other modules
    try {
        const navPel = document.getElementById('nav-peliculas');
        if (navPel) {
            navPel.addEventListener('click', (ev) => {
                ev.preventDefault();
                // prefer the new movies module if available
                try {
                        if (window.initMovies) {
                        window.initMovies({ dataPath: 'movies.json', containerId: 'movie-grid', exposeGlobal: true, typeFilter: 'pelicula' });
                        const grid = document.getElementById('movie-grid');
                        if (grid) grid.classList.add('movies-grid');
                        // show the grid and hide the main list container if present
                        const container = document.getElementById('movie-container');
                        if (grid) { grid.style.display = ''; grid.scrollIntoView({ behavior: 'smooth' }); }
                        if (container) container.style.display = 'none';
                    } else {
                        // fallback: fetch movies.json and render simply
                        fetch('movies.json').then(r => r.json()).then(data => {
                            const grid = document.getElementById('movie-grid');
                            if (!grid) return;
                            grid.innerHTML = '';
                            data.forEach(it => {
                                const div = document.createElement('div');
                                div.className = 'movie';
                                div.innerHTML = `<a href="${it.link}"><img src="${it.image}" alt="${it.title}" loading="lazy"><div class="movie-info"><h3>${it.title}</h3></div></a>`;
                                grid.appendChild(div);
                            });
                            grid.scrollIntoView({ behavior: 'smooth' });
                        }).catch(e => console.error('Failed loading movies.json', e));
                    }
                } catch (e) {
                    console.error('nav-peliculas handler error', e);
                }
            });
        }
    } catch (e) {
        console.error('Error setting up nav-peliculas handler', e);
    }
    // Nav: Inicio - show only items with type 'anime'
    try {
        const navInicio = document.getElementById('nav-inicio');
        if (navInicio) {
            navInicio.addEventListener('click', (ev) => {
                // allow normal navigation to page, but also ensure movie list shows anime
                try {
                    if (window.initMovies) {
                        ev.preventDefault();
                        window.initMovies({ dataPath: 'anime.json', containerId: 'movie-container', exposeGlobal: true, typeFilter: 'anime' });
                        const container = document.getElementById('movie-container');
                        if (container) container.classList.add('movies');
                        const grid = document.getElementById('movie-grid');
                        if (grid) grid.style.display = 'none';
                        if (container) {
                            container.style.display = '';
                            container.scrollIntoView({ behavior: 'smooth' });
                        }
                    }
                } catch (e) {
                    console.error('nav-inicio handler error', e);
                }
            });
        }
    } catch (e) {
        console.error('Error setting up nav-inicio handler', e);
    }

    // Nav: Series - show only items with type 'serie'
    try {
        const navSeries = document.getElementById('nav-series');
        if (navSeries) {
            navSeries.addEventListener('click', (ev) => {
                ev.preventDefault();
                try {
                    if (window.initMovies) {
                        window.initMovies({ dataPath: 'anime.json', containerId: 'movie-container', exposeGlobal: true, typeFilter: 'serie' });
                        const grid = document.getElementById('movie-grid');
                        const container = document.getElementById('movie-container');
                        if (container) {
                            container.classList.add('movies');
                            container.style.display = '';
                            container.scrollIntoView({ behavior: 'smooth' });
                        }
                        if (grid) grid.style.display = 'none';
                    }
                } catch (e) {
                    console.error('nav-series handler error', e);
                }
            });
        }
    } catch (e) {
        console.error('Error setting up nav-series handler', e);
    }
});
