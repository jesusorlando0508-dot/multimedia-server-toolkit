// fixPaths.js
async function loadAndFixJSON(url) {
    try {
        const response = await fetch(url);
        let data = await response.json();

        data = data.map(item => {
            // Normalizar barras invertidas para image
            if (item.image) {
                item.image = item.image.replace(/\\/g, '/');

                // Codificar solo el nombre de archivo
                const pathParts = item.image.split('/');
                const fileName = pathParts.pop();
                const encodedFileName = encodeURIComponent(fileName);
                item.image = [...pathParts, encodedFileName].join('/');
            }

            // Normalizar barras invertidas en links si es necesario
            if (item.link) {
                item.link = item.link.replace(/\\/g, '/');
            }

            return item;
        });

        return data;
    } catch (error) {
        console.error('Error cargando JSON:', error);
        return [];
    }
}


window.loadAndFixJSON = loadAndFixJSON;
