document.addEventListener('DOMContentLoaded', function () {
  // =========================
  // VARIABLES PRINCIPALES
  // =========================
  const mainTitle = localStorage.getItem('mainTitle') || 'Mi Lista de Videos';
  const videoTitles = JSON.parse(localStorage.getItem('videoTitles')) || ['Video 1', 'Video 2', 'Video 3'];
  const videoList = JSON.parse(localStorage.getItem('videoList')) || ['videos/video1.mp4', 'videos/video2.mp4', 'videos/video3.mp4'];
  let videoIndex = parseInt(localStorage.getItem('videoIndex')) || 0;

  const videoPlayer = document.getElementById('videoPlayer');
  const playlist = document.getElementById('playlistItems');
  const mainTitleElem = document.getElementById('mainTitle');
  const videoTitleElem = document.getElementById('videoTitle');
  const previousButton = document.getElementById('previousButton');
  const nextButton = document.getElementById('nextButton');
  const playerContainer = document.querySelector('.video-container');

  const playPauseBtn = document.getElementById('playPauseBtn');
  // Prefer an element with explicit id, otherwise fall back to the <img> inside the button
  const playPauseIcon = document.getElementById('playPauseIcon') || (playPauseBtn ? playPauseBtn.querySelector('img') : null);
  const centerPlayBtn = document.getElementById('centerPlayBtn');
  const seekBar = document.getElementById('seekBar');
  if (seekBar) seekBar.dragging = false;
  const muteBtn = document.getElementById('muteBtn');
  // Prefer an element with explicit id, otherwise fall back to the <img> inside the button
  const muteIcon = document.getElementById('muteIcon') || (muteBtn ? muteBtn.querySelector('img') : null);
  const volumeBar = document.getElementById('volumeBar');
  const fullscreenBtn = document.getElementById('fullscreenBtn');

  const currentTimeElem = document.getElementById('currentTime');
  const durationTimeElem = document.getElementById('durationTime');

  if (mainTitleElem) mainTitleElem.textContent = mainTitle;

  // =========================
  // OVERLAY TÍTULO (reutilizar si ya existe en el HTML)
  // =========================
  let overlay = document.getElementById('videoOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'videoOverlay';
    overlay.style.cssText = `
      position:absolute;top:0;left:0;width:100%;
      padding:12px 12px;background:rgba(0,0,0,0.3);
      color:#fff;font-size:1rem;font-weight:600;
      transition:opacity 0.5s ease;z-index:30;pointer-events:none;
    `;
    playerContainer.appendChild(overlay);
  } else {
    // ensure it's not interactive and has minimal style if author used a class
    overlay.style.pointerEvents = 'none';
  }
  overlay.textContent = videoTitles[videoIndex];

  let overlayTimer;
  function showOverlay() {
    overlay.style.opacity = '1';
    clearTimeout(overlayTimer);
    overlayTimer = setTimeout(() => overlay.style.opacity = '0', 3000);
  }
  playerContainer.addEventListener('mousemove', showOverlay);
  showOverlay();

  // =========================
  // FUNCIONES DE PLAYLIST
  // =========================
  function updatePlaylist() {
    playlist.innerHTML = '';
    videoTitles.forEach((title, index) => {
      const li = document.createElement('li');
      li.textContent = title;
      li.className = index === videoIndex ? 'active' : '';
      li.addEventListener('click', () => loadVideo(index));
      playlist.appendChild(li);
    });
  }

  function saveData() {
    localStorage.setItem('videoTitles', JSON.stringify(videoTitles));
    localStorage.setItem('videoList', JSON.stringify(videoList));
    localStorage.setItem('videoIndex', videoIndex.toString());
    localStorage.setItem('mainTitle', mainTitle);
  }

  function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  // =========================
  // SKIP DATA (OP / ED)
  // =========================
  let skipData = {};
  let skipBtnOp = document.getElementById("skip-op");
  let skipBtnEd = document.getElementById("skip-ed");
  const videoContainer = document.querySelector('.video-container');
  if (skipBtnOp && skipBtnOp.parentElement !== videoContainer) videoContainer.appendChild(skipBtnOp);
  if (skipBtnEd && skipBtnEd.parentElement !== videoContainer) videoContainer.appendChild(skipBtnEd);

  // Auto-skip timers and settings
  let skipOpTimer = null;
  let skipEdTimer = null;
  let skipOpInterval = null;
  let skipEdInterval = null;
  // Fixed default auto-skip delay (seconds) — configurable by editing this file if needed
  let SKIP_AUTO_DELAY = 7;

  function clearSkipOpTimer() {
    if (skipOpTimer) { clearTimeout(skipOpTimer); skipOpTimer = null; }
    if (skipOpInterval) { clearInterval(skipOpInterval); skipOpInterval = null; }
    // stop smooth fill animation if present
    if (skipBtnOp) stopFillAnimation(skipBtnOp);
  }
  function clearSkipEdTimer() {
    if (skipEdTimer) { clearTimeout(skipEdTimer); skipEdTimer = null; }
    if (skipEdInterval) { clearInterval(skipEdInterval); skipEdInterval = null; }
    if (skipBtnEd) stopFillAnimation(skipBtnEd);
  }

  // Create a circular SVG ring and numeric counter inside the skip button
  function createSkipRing(btn) {
    // Legacy: we no longer inject SVG ring by default. Instead create a skip-fill overlay
    if (!btn) return;
    if (btn.querySelector('.skip-fill')) return;
    // ensure button has relative positioning
    btn.style.position = btn.style.position || 'absolute';
    const fill = document.createElement('span'); fill.className = 'skip-fill';
    const content = document.createElement('span'); content.className = 'skip-content';
    // move existing text inside content
    while (btn.firstChild) {
      content.appendChild(btn.firstChild);
    }
    btn.appendChild(fill);
    btn.appendChild(content);
  }

  function startFillAnimation(btn, duration) {
    if (!btn) return;
    createSkipRing(btn); // ensures .skip-fill exists
    stopFillAnimation(btn);
    const fill = btn.querySelector('.skip-fill');
    const content = btn.querySelector('.skip-content');
    let start = performance.now();
    function frame(now) {
      const elapsed = (now - start) / 1000;
      const progress = Math.min(1, elapsed / duration);
      fill.style.width = (progress * 100) + '%';
      // keep looping until done
      if (progress < 1) btn._skipAnim = requestAnimationFrame(frame);
      else btn._skipAnim = null;
    }
    btn._skipAnim = requestAnimationFrame(frame);
  }

  function stopFillAnimation(btn) {
    if (!btn) return;
    if (btn._skipAnim) { cancelAnimationFrame(btn._skipAnim); btn._skipAnim = null; }
    const fill = btn.querySelector('.skip-fill');
    if (fill) fill.style.width = '0%';
    btn.removeAttribute('data-countdown');
  }

  function hideSkipButtons() {
    if (skipBtnOp) skipBtnOp.classList.remove("show");
    if (skipBtnEd) skipBtnEd.classList.remove("show");
    // clear timers and countdown badges
    clearSkipOpTimer();
    clearSkipEdTimer();
    if (skipBtnOp) skipBtnOp.removeAttribute('data-countdown');
    if (skipBtnEd) skipBtnEd.removeAttribute('data-countdown');
  }

  async function loadSkipDataForVideo(videoPath, index) {
    const filename = videoPath.substring(videoPath.lastIndexOf("/") + 1);
    const match = filename.match(/(\d+)/);
    const episodeNum = match ? parseInt(match[1].replace(/^0+/, ''), 10) : NaN;

    try {
      const res = await fetch(`/skip?video=${encodeURIComponent(videoList[index])}`);
      if (!res.ok) {
        skipData = {};
        hideSkipButtons();
        return;
      }

      const data = await res.json();
      const epObj = data.episodes?.find(ep => parseInt(ep.episode) === episodeNum);
      skipData = epObj?.skip_times || {};

      if (!skipData || Object.keys(skipData).length === 0) {
        hideSkipButtons();
        return;
      }

      if (skipBtnOp) {
        // remove previous clear handler if it exists to avoid duplicates
        if (skipBtnOp._clearHandler) skipBtnOp.removeEventListener('click', skipBtnOp._clearHandler);
        skipBtnOp.onclick = () => { videoPlayer.currentTime = skipData["skip-op_end"]; hideSkipButtons(); };
        // ensure click cancels auto timer - use a named handler so it can be removed later
        skipBtnOp._clearHandler = () => clearSkipOpTimer();
        skipBtnOp.addEventListener('click', skipBtnOp._clearHandler);
      }
      if (skipBtnEd) {
        // remove previous clear handler if it exists to avoid duplicates
        if (skipBtnEd._clearHandler) skipBtnEd.removeEventListener('click', skipBtnEd._clearHandler);
        skipBtnEd.onclick = () => { videoPlayer.currentTime = skipData["skip-ed_end"]; hideSkipButtons(); };
        // ensure click cancels auto timer - use a named handler so it can be removed later
        skipBtnEd._clearHandler = () => clearSkipEdTimer();
        skipBtnEd.addEventListener('click', skipBtnEd._clearHandler);
      }

    } catch (err) {
      skipData = {};
      hideSkipButtons();
    }
  }

  videoPlayer.addEventListener("timeupdate", () => {
    if (!skipData || Object.keys(skipData).length === 0) {
      hideSkipButtons();
      return;
    }
    const t = videoPlayer.currentTime;
    // OP visibility handling with auto-skip
    if (skipData["skip-op_start"] != null && skipData["skip-op_end"] != null && skipBtnOp) {
      const opVisible = t >= skipData["skip-op_start"] && t <= skipData["skip-op_end"];
      const wasVisible = skipBtnOp.classList.contains('show');
      skipBtnOp.classList.toggle('show', opVisible);
      if (opVisible && !wasVisible) {
            // start countdown with smooth fill animation (only if auto delay > 0)
            clearSkipOpTimer();
            if (SKIP_AUTO_DELAY > 0) {
              skipBtnOp.setAttribute('data-countdown', SKIP_AUTO_DELAY);
              startFillAnimation(skipBtnOp, SKIP_AUTO_DELAY);
              skipOpTimer = setTimeout(() => {
                if (skipData && skipData["skip-op_end"] != null) videoPlayer.currentTime = skipData["skip-op_end"];
                hideSkipButtons();
              }, SKIP_AUTO_DELAY * 1000);
            }
      } else if (!opVisible && wasVisible) {
        clearSkipOpTimer();
        skipBtnOp.removeAttribute('data-countdown');
      }
    }

    // ED visibility handling with auto-skip
    if (skipData["skip-ed_start"] != null && skipData["skip-ed_end"] != null && skipBtnEd) {
      const edVisible = t >= skipData["skip-ed_start"] && t <= skipData["skip-ed_end"];
      const wasVisibleEd = skipBtnEd.classList.contains('show');
      skipBtnEd.classList.toggle('show', edVisible);
      if (edVisible && !wasVisibleEd) {
        clearSkipEdTimer();
        if (SKIP_AUTO_DELAY > 0) {
          skipBtnEd.setAttribute('data-countdown', SKIP_AUTO_DELAY);
          startFillAnimation(skipBtnEd, SKIP_AUTO_DELAY);
          skipEdTimer = setTimeout(() => {
            if (skipData && skipData["skip-ed_end"] != null) videoPlayer.currentTime = skipData["skip-ed_end"];
            hideSkipButtons();
          }, SKIP_AUTO_DELAY * 1000);
        }
      } else if (!edVisible && wasVisibleEd) {
        clearSkipEdTimer();
        skipBtnEd.removeAttribute('data-countdown');
      }
    }
  });

  // =========================
  // FUNCIONES DE VIDEO
  // =========================
  function loadVideo(index) {
    mainTitleElem.textContent = mainTitle;
    videoTitleElem.textContent = videoTitles[index];
    overlay.textContent = videoTitles[index];

    let sourceEl = videoPlayer.querySelector('source');
    if (!sourceEl) { sourceEl = document.createElement('source'); videoPlayer.appendChild(sourceEl); }
    sourceEl.src = videoList[index];
    videoPlayer.load();
    videoIndex = index;
    saveData();
    updateButtons(index);
    updatePlaylist();
    document.querySelectorAll('#playlistItems li').forEach((item, i) => {
      item.classList.toggle('active', i === videoIndex);
    });

    loadSkipDataForVideo(videoList[index], index);
    document.addEventListener('click', () => videoPlayer.play(), { once: true });
  }

  function updateButtons(index) {
    previousButton.disabled = index <= 0;
    nextButton.disabled = index >= videoList.length - 1;
  }

  previousButton.addEventListener('click', () => { if (videoIndex > 0) loadVideo(--videoIndex); });
  nextButton.addEventListener('click', () => { if (videoIndex < videoList.length - 1) loadVideo(++videoIndex); });
  videoPlayer.addEventListener('ended', () => { if (videoIndex < videoList.length - 1) loadVideo(++videoIndex); });

  // =========================
  // PLAY/PAUSE Y VOLUMEN CON ICONOS
  // =========================
  function updateVolumeIcon() {
    if (!muteIcon) return;
    if (videoPlayer.muted || videoPlayer.volume === 0) muteIcon.src = 'icons/volume_off.svg';
    else if (videoPlayer.volume < 0.5) muteIcon.src = 'icons/volume_down.svg';
    else muteIcon.src = 'icons/volume_up.svg';
  }
  function updatePlayPauseIcon() {
    if (!playPauseIcon) return;
    playPauseIcon.src = videoPlayer.paused ? 'icons/play_arrow.svg' : 'icons/pause.svg';
  }

  playPauseBtn.addEventListener('click', () => {
    videoPlayer.paused ? videoPlayer.play() : videoPlayer.pause();
    updatePlayPauseIcon();
  });

  // Central play button: toggle play/pause and animate visibility
  if (centerPlayBtn) {
    centerPlayBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (videoPlayer.paused) videoPlayer.play(); else videoPlayer.pause();
      updatePlayPauseIcon();
    });
    // hide/show center button on play/pause
    videoPlayer.addEventListener('play', () => {
      centerPlayBtn.classList.add('hidden');
    });
    videoPlayer.addEventListener('pause', () => {
      // show with a small delay so quick toggles don't always flash
      setTimeout(() => centerPlayBtn.classList.remove('hidden'), 80);
    });
  }

  // Toggle play/pause when clicking on the video area (but not on controls)
  playerContainer.addEventListener('click', (e) => {
    // if clicking on custom controls, skip buttons, inputs, or selects, ignore
    if (e.target.closest('.custom-controls') || e.target.closest('.skip-buttons') || e.target.closest('input') || e.target.closest('select')) return;
    // centerPlayBtn stops propagation, so this will only run for general area clicks
    if (videoPlayer.paused) videoPlayer.play(); else videoPlayer.pause();
    updatePlayPauseIcon();
  });

  muteBtn.addEventListener('click', () => {
    videoPlayer.muted = !videoPlayer.muted;
    updateVolumeIcon();
    volumeBar.value = videoPlayer.muted ? 0 : videoPlayer.volume;
  });

  volumeBar.addEventListener('input', () => {
    videoPlayer.volume = Number(volumeBar.value);
    videoPlayer.muted = volumeBar.value == 0;
    updateVolumeIcon();
  });

  videoPlayer.addEventListener('play', updatePlayPauseIcon);
  videoPlayer.addEventListener('pause', updatePlayPauseIcon);

  // =========================
  // TECLADO
  // =========================
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    switch (e.key.toLowerCase()) {
      case 'l': toggleLoop(); break;
      case 's': captureScreenshot(); break;
      case '>': case '.': changeSpeed(1.25); break;
      case '<': case ',': changeSpeed(0.8); break;
      case ' ':
        e.preventDefault(); videoPlayer.paused ? videoPlayer.play() : videoPlayer.pause(); updatePlayPauseIcon();
        break;
      case 'arrowright': e.preventDefault(); videoPlayer.currentTime += 10; break;
      case 'arrowleft': e.preventDefault(); videoPlayer.currentTime -= 10; break;
      case 'arrowup':
        e.preventDefault(); videoPlayer.volume = Math.min(1, videoPlayer.volume + 0.05);
        videoPlayer.muted = false; volumeBar.value = videoPlayer.volume; updateVolumeIcon();
        break;
      case 'arrowdown':
        e.preventDefault(); videoPlayer.volume = Math.max(0, videoPlayer.volume - 0.05);
        videoPlayer.muted = videoPlayer.volume === 0; volumeBar.value = videoPlayer.volume; updateVolumeIcon();
        break;
      case 'm': if (videoIndex < videoList.length - 1) loadVideo(++videoIndex); break;
      case 'n': if (videoIndex > 0) loadVideo(--videoIndex); break;
      case 'f': toggleFullscreen(); break;
    }
    resetInactivityTimer();
  });

  // =========================
  // SEEK Y TIEMPO
  // =========================
  videoPlayer.addEventListener('loadedmetadata', () => { durationTimeElem.textContent = formatTime(videoPlayer.duration); });
  videoPlayer.addEventListener('timeupdate', () => {
    if (!seekBar.dragging && seekBar) {
      if (isFinite(videoPlayer.duration) && videoPlayer.duration > 0) seekBar.value = (videoPlayer.currentTime / videoPlayer.duration) * 100 || 0;
      currentTimeElem.textContent = formatTime(videoPlayer.currentTime);
    }
  });
  seekBar.addEventListener('input', () => {
    seekBar.dragging = true;
    const time = (seekBar.value / 100) * videoPlayer.duration;
    videoPlayer.currentTime = time;
    currentTimeElem.textContent = formatTime(time);
  });
  seekBar.addEventListener('change', () => seekBar.dragging = false);

  // =========================
  // FULLSCREEN Y SWIPE
  // =========================
  fullscreenBtn.addEventListener('click', toggleFullscreen);
  videoPlayer.addEventListener('dblclick', toggleFullscreen);

  let lastTap = 0;
  videoPlayer.addEventListener('touchend', e => {
    const currentTime = new Date().getTime();
    if (currentTime - lastTap < 300) { toggleFullscreen(); e.preventDefault(); }
    lastTap = currentTime;
  });

  async function toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        await playerContainer.requestFullscreen({ navigationUI: 'hide' });
        if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => { });
      } else {
        await document.exitFullscreen();
        if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
      }
    } catch (err) { console.log(err); }
  }

  if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
    let startY = 0, startX = 0;
    videoPlayer.addEventListener('touchstart', e => { startY = e.touches[0].clientY; startX = e.touches[0].clientX; });
    videoPlayer.addEventListener('touchmove', e => {
      const endY = e.touches[0].clientY; const deltaY = startY - endY;
      if (startX < window.innerWidth / 2) {
        videoPlayer.volume = Math.min(1, Math.max(0, videoPlayer.volume + deltaY / 300));
        videoPlayer.muted = videoPlayer.volume === 0;
        volumeBar.value = videoPlayer.volume;
        startY = endY;
      }
    });
    videoPlayer.addEventListener('touchend', e => {
      const endY = e.changedTouches[0].clientY;
      const deltaY = startY - endY;
      if (deltaY > 50 && !document.fullscreenElement) toggleFullscreen();
      else if (deltaY < -50 && document.fullscreenElement) toggleFullscreen();
    });
  }

  // =========================
  // OCULTAR CONTROLES POR INACTIVIDAD
  // =========================
  let inactivityTimer;
  const hideDelay = 3000;
  const controlsContainer = document.querySelector('.custom-controls');

  function showUI() {
    playerContainer.classList.remove('hide-cursor');
    controlsContainer.classList.remove('hide-bar');
    controlsContainer.classList.add('show-bar');
    overlay.style.opacity = '1';
  }
  function hideUI() {
    playerContainer.classList.add('hide-cursor');
    controlsContainer.classList.remove('show-bar');
    controlsContainer.classList.add('hide-bar');
    overlay.style.opacity = '0';
  }
  function resetInactivityTimer() {
    showUI();
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(() => hideUI(), hideDelay);
  }
  playerContainer.addEventListener('mousemove', resetInactivityTimer);
  playerContainer.addEventListener('click', resetInactivityTimer);
  document.addEventListener('keydown', resetInactivityTimer);
  videoPlayer.addEventListener('play', resetInactivityTimer);
  videoPlayer.addEventListener('pause', showUI);
  document.addEventListener('fullscreenchange', resetInactivityTimer);

  // =========================
  // FUNCIONES EXTRA
  // =========================
  let isLoop = false;
  let playbackRate = 1;
  let sleepTimer;

  function toggleLoop() { isLoop = !isLoop; videoPlayer.loop = isLoop; showNotification(isLoop ? 'Loop activado' : 'Loop desactivado'); }
  function changeSpeed(factor) { playbackRate = Math.min(2, Math.max(0.25, playbackRate * factor)); videoPlayer.playbackRate = playbackRate; showNotification(`Velocidad: ${playbackRate.toFixed(2)}x`); }
  function captureScreenshot() {
    const canvas = document.createElement('canvas'); canvas.width = videoPlayer.videoWidth; canvas.height = videoPlayer.videoHeight;
    canvas.getContext('2d').drawImage(videoPlayer, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(blob => {
      const url = URL.createObjectURL(blob); const a = document.createElement('a');
      a.href = url; a.download = `${videoTitles[videoIndex]}_${new Date().toISOString().replace(/:/g, '-')}.png`; a.click();
      URL.revokeObjectURL(url);
    });
    showNotification('Captura guardada');
  }
  function setSleepTimer(minutes) {
    clearTimeout(sleepTimer);
    if (minutes > 0) {
      sleepTimer = setTimeout(() => { videoPlayer.pause(); showNotification('Temporizador activado: video pausado'); }, minutes * 60000);
      showNotification(`Temporizador configurado para ${minutes} minutos`);
    } else showNotification('Temporizador cancelado');
  }

  // =========================
  // NOTIFICACIONES
  // =========================
  function showNotification(message) {
    const existing = document.querySelector('.notification'); if (existing) existing.remove();
    const notification = document.createElement('div'); notification.className = 'notification'; notification.textContent = message;
    notification.style.cssText = `
      position:fixed;bottom:30px;left:50%;
      transform:translateX(-50%);
      background-color:rgba(0,0,0,0.8);
      color:white;padding:10px 20px;
      border-radius:5px;z-index:1000;
      transition:opacity 0.5s ease;
    `;
    document.body.appendChild(notification);
    setTimeout(() => { notification.style.opacity = '0'; setTimeout(() => notification.remove(), 500); }, 3000);
  }

  // =========================
  // INICIALIZAR
  // =========================
  loadVideo(videoIndex);
  updatePlaylist();
});
