// Función global para ocultar overlay
function resetOverlay() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.display = 'none';
        overlay.classList.remove('show');
    }
}

function setupHoverPreview() {
    // avoid double initialization if function called multiple times
    if (window._hoverPreviewInitialized) return;
    window._hoverPreviewInitialized = true;
    const preview = document.getElementById('hover-preview');
    const previewVideo = document.getElementById('hover-video');
    const hoverTitle = document.getElementById('hover-title');
    const previewText = document.getElementById('hover-synopsis');
    const addToListBtn = document.getElementById('add-to-list-btn');
    const playNowBtn = document.getElementById('play-now-btn');
    const volumeToggleBtn = document.getElementById('volume-toggle-btn');

    if (!preview || !previewVideo || !hoverTitle || !previewText || !addToListBtn || !playNowBtn || !volumeToggleBtn) {
        console.error('No se encontraron los elementos del hover preview');
        return;
    }

    let mainJson = [];
    let detailJson = [];
    let currentTrailers = [];
    let currentIndex = 0;
    let isMuted = true;
    let activeItem = null;
    let previewVisible = false;

    // Precalcular dimensiones del preview
    let previewWidth = 0, previewHeight = 0;
    preview.style.display = 'block';
    previewWidth = preview.offsetWidth;
    previewHeight = preview.offsetHeight;
    preview.style.display = 'none';

    // Cargar JSONs (usar loadAndFixJSON para normalizar rutas si está disponible)
    Promise.all([
        (window.loadAndFixJSON ? window.loadAndFixJSON('anime.json') : fetch('anime.json').then(res => res.json())),
        fetch('anime1_info.json').then(res => res.json())
    ]).then(([mainData, detailData]) => {
        mainJson = mainData;
        // support both formats: either an array or an object with `animesDetail`
        if (Array.isArray(detailData)) {
            detailJson = detailData;
        } else {
            detailJson = detailData?.animesDetail || [];
        }
        console.log('JSON principal y detalle cargados (main items:', (mainJson||[]).length, 'details:', (detailJson||[]).length, ')');
    }).catch(err => console.error('Error cargando JSONs:', err));

    // ==============================
    // Funciones internas
    // ==============================

    function playCurrentTrailer() {
        if (!currentTrailers.length) {
            // no trailer: hide video element but keep poster if available
            try { previewVideo.pause(); } catch (e) {}
            try { previewVideo.removeAttribute('src'); previewVideo.load(); } catch (e) {}
            previewVideo.style.display = 'none';
            return;
        }
        // set preload and muted before attempting to play to improve autoplay success
        previewVideo.preload = 'auto';
        previewVideo.muted = isMuted;
        previewVideo.volume = 0.5;
        const src = currentTrailers[currentIndex];
        if (!src) {
            previewVideo.style.display = 'none';
            return;
        }
        previewVideo.src = src;
        previewVideo.style.display = 'block';
        // ensure browser shows poster until video can play
        // will try to play; if blocked, user still sees poster/thumbnail
        previewVideo.load();
        previewVideo.play().catch(e => {
            // autoplay may be blocked; keep poster visible and log
            console.log('Auto-play fallido:', e);
        });
        volumeToggleBtn.textContent = isMuted ? '🔈' : '🔊';
    }

    previewVideo.addEventListener('ended', () => {
        currentIndex = (currentIndex + 1) % currentTrailers.length;
        playCurrentTrailer();
    });

    // ensure initial muted state on the element matches our flag
    try { previewVideo.muted = isMuted; } catch (e) {}
    volumeToggleBtn.textContent = isMuted ? '🔈' : '🔊';
    volumeToggleBtn.addEventListener('click', () => {
        isMuted = !isMuted;
        previewVideo.muted = isMuted;
        volumeToggleBtn.textContent = isMuted ? '🔈' : '🔊';
    });

    addToListBtn.addEventListener('click', () => {
        alert('Agregado a tu lista (simulado)');
    });

    function hidePreview() {
        if (!previewVisible) return;
        previewVideo.pause();
        previewVideo.src = '';
        preview.style.display = 'none';
        currentTrailers = [];
        currentIndex = 0;
        activeItem = null;
        previewVisible = false;
        if (typeof startCarousel === 'function') startCarousel();
    }

    function normalizeLinkForMatch(s) {
        if (!s) return '';
        try {
            // resolve relative URLs
            const u = new URL(s, location.href);
            s = u.pathname || s;
        } catch (e) {
            // ignore
        }
        s = (s + '').split('?')[0].split('#')[0];
        s = s.replace(/\\/g, '/');
        const parts = s.split('/').filter(Boolean);
        return (parts.length ? parts[parts.length - 1] : s).toString().trim().toLowerCase();
    }

    function showPreview(item) {
        activeItem = item;
        const link = item.getAttribute('data-link') || '';
        const titleText = (item.querySelector('.carousel-title')?.textContent || '').trim().toLowerCase();
        const normLink = normalizeLinkForMatch(link);
        // try match by normalized link first, then fallback to title match
        let detailAnime = detailJson.find(a => normalizeLinkForMatch(a.link) === normLink);
        if (!detailAnime && titleText) {
            detailAnime = detailJson.find(a => (a.title || '').toString().trim().toLowerCase() === titleText);
        }
        if (!detailAnime) {
            console.debug('hoverPreview: no matching detail for', { link, normLink, titleText });
            return;
        }

        hoverTitle.textContent = item.querySelector('.carousel-title')?.textContent || 'Sin título';
        previewText.textContent = item.dataset.synopsis || 'Sin sinopsis disponible.';

        // pick episodes that have a videoPath
        const validEpisodes = Array.isArray(detailAnime.episodes) ? detailAnime.episodes.filter(ep => ep && (ep.videoPath || ep.videoPath === '')) : [];
        if (!validEpisodes.length) {
            currentTrailers = [];
        } else {
            const randomIndex = Math.floor(Math.random() * validEpisodes.length);
            const chosen = validEpisodes[randomIndex];
            currentTrailers = chosen && chosen.videoPath ? [chosen.videoPath] : [];
        }
        currentIndex = 0;

        playCurrentTrailer();

        // seek to a random start once we have enough data to seek
        previewVideo.addEventListener('loadedmetadata', () => {
            try {
                previewVideo.currentTime = Math.random() * Math.min(30, previewVideo.duration || 30);
            } catch (e) { /* ignore seek errors */ }
        }, { once: true });

        // hide poster (if any) once the video can actually play
        previewVideo.addEventListener('canplay', () => {
            // when video is ready, ensure it's visible (poster hidden automatically by browser)
            previewVideo.style.display = 'block';
        }, { once: true });

        const rect = item.getBoundingClientRect();
        let left = rect.right + 10;
        let top = rect.top;
        if (left + previewWidth > window.innerWidth) left = rect.left - previewWidth - 10;
        if (top + previewHeight > window.innerHeight) top = window.innerHeight - previewHeight - 10;

        // set poster from the item's image to provide an immediate thumbnail while the video loads
        const itemImg = item.querySelector('img');
        if (itemImg && itemImg.src) {
            try { previewVideo.poster = itemImg.src; } catch (e) { /* ignore */ }
        }

        preview.style.left = `${left + window.scrollX}px`;
        preview.style.top = `${top + window.scrollY}px`;
        preview.style.display = 'block';
        previewVisible = true;

        // Try to pause the carousel if the host page exposes a control.
        if (typeof pauseCarousel === 'function') {
            try { pauseCarousel(); } catch (e) { console.warn('pauseCarousel failed', e); }
        } else if (typeof window.carouselInterval !== 'undefined' && window.carouselInterval) {
            clearInterval(window.carouselInterval);
            window.carouselInterval = null;
        }
    }

    // ==============================
    // Eventos del hover
    // ==============================
    document.addEventListener('mouseover', e => {
        const item = e.target.closest('.carousel-item');
        if (item && item !== activeItem) showPreview(item);
    });

    document.addEventListener('mouseout', e => {
        const relatedTarget = e.relatedTarget;
        if (!relatedTarget || (!preview.contains(relatedTarget) && (!activeItem || !activeItem.contains(relatedTarget)))) {
            hidePreview();
        }
    });

    document.addEventListener('mousemove', e => {
        const hoveredOnPreview = preview.contains(e.target);
        const hoveredOnCarouselItem = e.target.closest('.carousel-item') !== null;
        if (!(hoveredOnPreview || hoveredOnCarouselItem) && typeof startCarousel === 'function') startCarousel();
    });

    window.addEventListener('scroll', () => {
        if (previewVisible) hidePreview();
    });

    // ==============================
    // Evento Play Now
    // ==============================
    playNowBtn.addEventListener('click', () => {
        if (!activeItem) return;

        const link = activeItem.getAttribute('data-link') || '';
        const normalizeLink = str => str.trim().toLowerCase();

        const mainAnime = mainJson.find(a => normalizeLink(a.link) === normalizeLink(link));
        const detailAnime = detailJson.find(a => normalizeLink(a.link) === normalizeLink(link));

        if (!mainAnime || !detailAnime) {
            alert('Información del anime no disponible.');
            return;
        }

        try {
            const videoTitles = detailAnime.episodes.map(ep => ep.title);
            const videoList = detailAnime.episodes.map(ep => ep.videoPath);

            localStorage.setItem('mainTitle', mainAnime.title);
            localStorage.setItem('videoTitles', JSON.stringify(videoTitles));
            localStorage.setItem('videoList', JSON.stringify(videoList));
            localStorage.setItem('videoIndex', '0');

            const overlay = document.getElementById('loading-overlay');
            if (overlay) overlay.classList.add('show');

            setTimeout(() => {
                window.location.href = '/media_all/V1.HTML';
            }, 500);

        } catch (err) {
            console.error('Error guardando información en localStorage:', err);
            alert('No se pudo iniciar la reproducción. Intenta de nuevo.');
        }
    });
}

// ==============================
// Inicialización
// ==============================
document.addEventListener("DOMContentLoaded", () => {
    setupHoverPreview();
    resetOverlay();
});

window.addEventListener("pageshow", (event) => {
    if (event.persisted) { // volver desde cache
        resetOverlay();
    }
});
