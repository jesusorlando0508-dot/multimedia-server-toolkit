// movies.js — unified renderer for anime/movies
// Exposes window.moviesModule and convenience globals for backward compatibility
(function () {
    'use strict';

    const norm = (s) => (s || '').toString().replace(/\\/g, '/');

    function safeHref(h) {
        if (!h) return '#';
        try {
            const url = new URL(h, location.href);
            if (url.protocol === 'http:' || url.protocol === 'https:' || url.protocol === 'data:' || url.protocol === 'file:') return url.href;
            return '#';
        } catch (e) {
            return '#';
        }
    }

    function safeImgSrc(s) {
        if (!s) return '';
        return norm(s);
    }

    function createCard(item) {
        if (typeof window !== 'undefined' && typeof window.createStandardMovieCard === 'function') {
            return window.createStandardMovieCard({
                ...item,
                link: safeHref(item.link || item.url || '#'),
                image: safeImgSrc(item.image || item.poster || ''),
            });
        }

        const fallback = document.createElement('div');
        fallback.className = 'movie movie-card';
        fallback.textContent = item.title || '';
        return fallback;
    }

    function renderList(items, container) {
        if (!container) return;
        container.innerHTML = '';
        const frag = document.createDocumentFragment();
        items.forEach(it => frag.appendChild(createCard(it)));
        container.appendChild(frag);
    }

    const moviesModule = {
        data: null,

        init: async function (opts = {}) {
            // opts: { containerId, loadData, exposeGlobal, dataPath }
            const containerId = opts.containerId || 'movie-container';
            const container = document.getElementById(containerId);
            const loadingMsg = document.getElementById('loading-message');
            const activeFilter = document.getElementById('active-filter');
            if (loadingMsg) loadingMsg.style.display = 'block';

            let data = [];
            try {
                const dataPath = opts.dataPath || 'anime.json';
                if (opts.loadData === false) {
                    data = window.movies || [];
                } else if (window.loadAndFixJSON) {
                    try {
                        data = await window.loadAndFixJSON(dataPath);
                    } catch (e) {
                        const r = await fetch(dataPath);
                        data = await r.json();
                    }
                } else {
                    const r = await fetch(dataPath);
                    data = await r.json();
                }
            } catch (err) {
                console.error('moviesModule: error loading data', err);
                if (container) container.innerHTML = '<p class="error-message">Error al cargar animes.</p>';
                if (loadingMsg) loadingMsg.style.display = 'none';
                return;
            }

            this.data = Array.isArray(data) ? data : (data || []);
            if (opts.exposeGlobal) {
                try { window.movies = this.data; } catch (e) { /* ignore */ }
            }

            try {
                const params = new URLSearchParams(window.location.search);
                const tag = params.get('tag');
                if (tag) {
                    const filtered = this.data.filter(anime => Array.isArray(anime.genres) && anime.genres.includes(tag));
                    if (activeFilter) { activeFilter.textContent = `Mostrando género: ${tag}`; activeFilter.style.display = 'block'; }
                    renderList(filtered, container);
                } else {
                    // Support explicit type filter (opts.typeFilter), otherwise default to showing 'anime' items
                    const typeFilter = (opts.typeFilter || 'anime').toString().toLowerCase();
                    const filteredByType = this.data.filter(i => (i.type || '').toString().toLowerCase() === typeFilter);
                    // If no items matched the requested type, fall back to rendering all items
                    renderList(filteredByType.length ? filteredByType : this.data, container);
                }
            } catch (e) {
                console.error('moviesModule: render error', e);
            }

            if (loadingMsg) loadingMsg.style.display = 'none';
        },

        filtrarIdioma: function (idioma, opts = {}) {
            const container = document.getElementById(opts.containerId || 'movie-container');
            const activeFilter = document.getElementById('active-filter');
            if (!this.data) return;
            const filtered = this.data.filter(m => (m.idioma || '').toString().toLowerCase() === (idioma || '').toString().toLowerCase());
            renderList(filtered, container);
            if (activeFilter) { activeFilter.textContent = `Filtrando idioma: ${idioma}`; activeFilter.style.display = 'block'; }
        },

        renderAll: function (containerId) {
            const container = document.getElementById(containerId || 'movie-container');
            if (!this.data) return;
            renderList(this.data, container);
        }
    };

    try {
        window.moviesModule = moviesModule;
        window.initMovies = (opts) => moviesModule.init(opts);
        window.filtrarIdioma = function (idioma, opts) {
            try {
                if (window.moviesModule && typeof window.moviesModule.filtrarIdioma === 'function') {
                    return window.moviesModule.filtrarIdioma(idioma, opts || {});
                }
            } catch (e) {
                console.error('filtrarIdioma helper failed', e);
            }
            return null;
        };
        window.renderAllMovies = function (containerId) {
            try {
                if (window.moviesModule && typeof window.moviesModule.renderAll === 'function') {
                    return window.moviesModule.renderAll(containerId);
                }
            } catch (e) {
                console.error('renderAllMovies helper failed', e);
            }
        };
    } catch (e) {
        // swallow
    }

})();
